# Daily Tracker - Family Chore Management System

## Overview

Daily Tracker is a comprehensive family chore management system built with a full-stack TypeScript architecture. It's designed to help families organize daily tasks, track completion, manage allowances, and gamify household responsibilities. The application supports multiple family members with role-based access (parents and children) and features time estimation challenges, photo verification, and rotating chore assignments.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI with shadcn/ui component library
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite for development and production builds
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **API**: RESTful API with structured error handling
- **File Uploads**: Multer for photo upload handling
- **Development**: Hot reloading with Vite middleware integration

### Data Storage Solutions
- **Database**: PostgreSQL with Neon serverless hosting
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Connection Pooling**: Neon serverless connection pooling

## Key Components

### 1. Daily Task Management System
- **Task Types**: Routine, chore, meal, and activity categorization
- **Scheduling**: Time-based task scheduling with recurring patterns
- **Assignment**: Family member assignment with rotation support
- **Completion Tracking**: Photo verification and completion timestamping
- **Streak Counting**: Consecutive day completion tracking

### 2. Time Estimation Challenge
- **Gamification**: Users estimate task completion time before starting
- **Accuracy Scoring**: Points awarded based on estimation accuracy
- **Performance Analytics**: Individual estimation statistics and improvement tracking
- **Real-time Timing**: Task timer with start/stop functionality

### 3. Allowance and Payment System
- **Value Assignment**: Monetary value assignment to tasks (stored in cents)
- **Earnings Tracking**: Automatic calculation of earned allowances
- **Payment History**: Complete audit trail of all payments
- **Outstanding Balance**: Real-time calculation of unpaid earnings

### 4. User Role Management
- **Parent Role**: Full task management, payment processing, system configuration
- **Child Role**: Task viewing, completion, time estimation participation
- **Display Names**: User-friendly naming system separate from login credentials

### 5. Media Management
- **Photo Uploads**: Task completion verification through photos
- **File Storage**: Local file system storage with web serving
- **Image Processing**: File type validation and size limits (50MB)

## Data Flow

### 1. Task Creation Flow
1. Parent creates task through management interface
2. Task data validated against Zod schema
3. Database insertion via Drizzle ORM
4. Real-time UI update through TanStack Query invalidation

### 2. Task Completion Flow
1. Child selects task and optionally participates in time estimation
2. Photo upload for verification (optional)
3. Completion timestamp and streak calculation
4. Allowance value added to outstanding balance
5. UI updates across all components

### 3. Payment Processing Flow
1. Parent reviews outstanding balances
2. Payment creation with recipient and amount
3. Database transaction for payment record
4. Outstanding balance recalculation
5. Payment history update

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form
- **Routing**: Wouter for lightweight routing
- **State Management**: TanStack Query for server state
- **UI Framework**: Radix UI primitives with shadcn/ui

### Database and Backend
- **Database**: Neon PostgreSQL serverless
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Server**: Express.js with TypeScript
- **File Handling**: Multer for multipart form uploads

### Development Tools
- **Build Tool**: Vite with React plugin
- **Type Checking**: TypeScript with strict configuration
- **Styling**: Tailwind CSS with PostCSS
- **Code Quality**: ESLint integration (configured via Vite)

### Validation and Utilities
- **Schema Validation**: Zod for runtime type checking
- **CSS Utilities**: clsx and tailwind-merge for conditional styling
- **Date Handling**: Native JavaScript Date API
- **Icons**: Lucide React for consistent iconography

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with hot reloading
- **Database**: Neon development database with connection pooling
- **File Uploads**: Local filesystem storage in `uploads/` directory
- **Port Configuration**: Development server on port 5000

### Production Build
- **Frontend Build**: Vite production build to `dist/public`
- **Backend Build**: esbuild compilation to `dist/index.js`
- **Static Assets**: Express static file serving for uploads
- **Environment Variables**: DATABASE_URL for production database connection

### Replit Deployment
- **Modules**: Node.js 20, Web, PostgreSQL 16
- **Build Command**: `npm run build`
- **Start Command**: `npm run start`
- **Auto-scaling**: Configured for automatic scaling deployment

## Changelog

```
Changelog:
- June 20, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```