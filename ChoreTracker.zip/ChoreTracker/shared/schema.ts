import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  role: text("role").notNull().default("child"), // "parent" or "child"
  createdAt: timestamp("created_at").defaultNow(),
});

export const dailyTasks = pgTable("daily_tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  assignedTo: text("assigned_to").notNull(),
  taskType: text("task_type").notNull(), // 'routine', 'chore', 'meal', 'activity'
  scheduledTime: text("scheduled_time").notNull(), // HH:MM format
  value: integer("value").default(0), // points/allowance in cents
  isCompleted: boolean("is_completed").default(false),
  completedAt: text("completed_at"),
  photoUrl: text("photo_url"),
  icon: text("icon").default("Clock"),
  alarmEnabled: boolean("alarm_enabled").default(false),
  recurring: boolean("recurring").default(true), // daily recurring task
  lastCompletedDate: text("last_completed_date"), // YYYY-MM-DD format
  streakCount: integer("streak_count").default(0), // consecutive days completed
  recurringDays: text("recurring_days").default("1,2,3,4,5,6,7"), // 1=Mon, 7=Sun
  isRotating: boolean("is_rotating").default(false),
  rotationGroup: text("rotation_group"), // Group identifier for rotating chores
  rotationOrder: integer("rotation_order").default(0), // Order in rotation
  // Time estimation challenge fields
  estimatedMinutes: integer("estimated_minutes"), // User's time estimate
  actualMinutes: integer("actual_minutes"), // Actual time taken
  startedAt: text("started_at"), // When task was started (ISO string)
  estimationPoints: integer("estimation_points").default(0), // Points earned for good estimates
  gamificationEnabled: boolean("gamification_enabled").default(false), // Per-task gamification control
  createdAt: timestamp("created_at").defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  recipientName: text("recipient_name").notNull(),
  amount: integer("amount").notNull(), // in cents
  description: text("description").notNull(),
  paidAt: text("paid_at").notNull(),
  choreId: integer("chore_id"),
});

export const insertDailyTaskSchema = createInsertSchema(dailyTasks).omit({
  id: true,
  isCompleted: true,
  completedAt: true,
  photoUrl: true,
  lastCompletedDate: true,
  streakCount: true,
  createdAt: true,
}).extend({
  scheduledTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Please enter time in HH:MM format"),
  taskType: z.enum(["routine", "chore", "meal", "activity"]),
  icon: z.string().default("Clock"),
  alarmEnabled: z.boolean().default(false),
  recurring: z.boolean().default(true),
  recurringDays: z.string().default("1,2,3,4,5,6,7"), // Mon-Sun
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  paidAt: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
  role: true,
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export const signupSchema = insertUserSchema.extend({
  password: z.string().min(4, "Password must be at least 4 characters"),
  username: z.string().min(2, "Username must be at least 2 characters"),
  displayName: z.string().min(1, "Display name is required"),
  role: z.enum(["parent", "child"]).default("child"),
});

export type InsertDailyTask = z.infer<typeof insertDailyTaskSchema>;
export type DailyTask = typeof dailyTasks.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
