import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDailyTaskSchema, insertPaymentSchema, dailyTasks } from "@shared/schema";
import { db, pool } from "./db";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for photo uploads
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const upload = multer({
  dest: uploadsDir,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Add basic middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Serve uploaded images
  app.use('/api/uploads', express.static(uploadsDir));

  // Get all daily tasks
  app.get('/api/daily-tasks', async (req, res) => {
    try {
      console.log('Attempting to fetch daily tasks...');
      const tasks = await storage.getAllDailyTasks();
      console.log('Fetched tasks:', tasks.length);
      res.json(tasks);
    } catch (error: any) {
      console.error('Database error:', error);
      res.status(500).json({ message: 'Failed to fetch daily tasks', error: error.message });
    }
  });

  // Function to handle weekly chore rotation
  async function rotateWeeklyChores() {
    const today = new Date();
    const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
    
    // Only rotate on Mondays (start of new week)
    if (dayOfWeek !== 1) return;
    
    try {
      console.log("Rotating weekly chores...");
      
      // Get all rotating chores
      const result = await pool.query(`
        SELECT * FROM daily_tasks 
        WHERE is_rotating = true 
        ORDER BY rotation_group, assigned_to, rotation_order
      `);
      
      if (result.rows.length === 0) return;
      
      // Group by rotation group and assigned person
      const rotationGroups: Record<string, any[]> = {};
      for (const task of result.rows) {
        const groupKey = `${task.rotation_group || 'default'}_${task.assigned_to}`;
        if (!rotationGroups[groupKey]) rotationGroups[groupKey] = [];
        rotationGroups[groupKey].push(task);
      }
      
      // Define the chore rotation cycle
      const choreNames = [
        "Load dishwasher",
        "Unload dishwasher", 
        "Clear off counters and table",
        "Sweep/vacuum"
      ];
      
      // Rotate each person's chores
      for (const [groupKey, tasks] of Object.entries(rotationGroups)) {
        for (const task of tasks) {
          // Move to next chore in rotation
          const currentOrder = task.rotation_order || 0;
          const nextOrder = (currentOrder + 1) % choreNames.length;
          const newChore = choreNames[nextOrder];
          
          await pool.query(`
            UPDATE daily_tasks 
            SET title = $1, 
                rotation_order = $2,
                is_completed = false,
                completed_at = NULL,
                photo_url = NULL
            WHERE id = $3
          `, [newChore, nextOrder, task.id]);
          
          console.log(`Rotated ${task.assigned_to}'s chore to: ${newChore}`);
        }
      }
      
      console.log("Weekly chore rotation completed!");
    } catch (error) {
      console.error('Error rotating weekly chores:', error);
    }
  }

  // Function to reset daily recurring tasks
  async function resetDailyTasks() {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const dayOfWeek = new Date().getDay() || 7; // Convert Sunday=0 to Sunday=7
    
    try {
      // Get all recurring tasks that should be active today
      const result = await pool.query(`
        SELECT id, last_completed_date, streak_count, recurring_days 
        FROM daily_tasks 
        WHERE recurring = true
      `);
      
      for (const task of result.rows) {
        const recurringDays = task.recurring_days.split(',').map((d: string) => parseInt(d));
        const shouldBeActiveToday = recurringDays.includes(dayOfWeek);
        
        if (shouldBeActiveToday) {
          // If this task was completed yesterday, increment streak
          const yesterday = new Date();
          yesterday.setDate(yesterday.getDate() - 1);
          const yesterdayStr = yesterday.toISOString().split('T')[0];
          
          if (task.last_completed_date === yesterdayStr) {
            // Task was completed yesterday, reset for today and maintain streak
            await pool.query(`
              UPDATE daily_tasks 
              SET is_completed = false, 
                  completed_at = NULL, 
                  photo_url = NULL
              WHERE id = $1
            `, [task.id]);
          } else if (task.last_completed_date !== today) {
            // Task wasn't completed yesterday, reset streak
            await pool.query(`
              UPDATE daily_tasks 
              SET is_completed = false, 
                  completed_at = NULL, 
                  photo_url = NULL,
                  streak_count = 0
              WHERE id = $1
            `, [task.id]);
          }
        }
      }
      
      // Check for weekly chore rotation (runs on Mondays)
      await rotateWeeklyChores();
      
    } catch (error) {
      console.error('Error resetting daily tasks:', error);
    }
  }

  // Create a new daily task
  app.post('/api/daily-tasks', async (req, res) => {
    try {
      const taskData = insertDailyTaskSchema.parse(req.body);
      const task = await storage.createDailyTask(taskData);
      res.status(201).json(task);
    } catch (error: any) {
      res.status(400).json({ message: 'Invalid task data', error: error.message });
    }
  });

  // Update a daily task
  app.patch('/api/daily-tasks/:id', async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const updates = req.body;
      
      const updatedTask = await storage.updateDailyTask(taskId, updates);
      if (!updatedTask) {
        return res.status(404).json({ message: 'Task not found' });
      }
      
      res.json(updatedTask);
    } catch (error: any) {
      res.status(400).json({ message: 'Failed to update task', error: error.message });
    }
  });

  // Upload photo for task completion
  app.post('/api/daily-tasks/:id/photo', upload.single('photo'), async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      
      if (!req.file) {
        return res.status(400).json({ message: 'No photo uploaded' });
      }

      const photoUrl = `/api/uploads/${req.file.filename}`;
      const completedAt = new Date().toISOString();
      const today = new Date().toISOString().split('T')[0];
      
      // Get current task to check if recurring
      const taskResult = await pool.query('SELECT * FROM daily_tasks WHERE id = $1', [taskId]);
      if (taskResult.rows.length === 0) {
        return res.status(404).json({ message: 'Task not found' });
      }
      
      const task = taskResult.rows[0];
      let newStreakCount = task.streak_count || 0;
      
      // If this is a recurring task and not completed today yet
      if (task.recurring && task.last_completed_date !== today) {
        // Check if completed yesterday to maintain streak
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().split('T')[0];
        
        if (task.last_completed_date === yesterdayStr) {
          newStreakCount += 1; // Continue streak
        } else {
          newStreakCount = 1; // Start new streak
        }
      }
      
      // Update task completion with streak tracking
      await pool.query(`
        UPDATE daily_tasks 
        SET is_completed = true, 
            completed_at = $1, 
            photo_url = $2,
            last_completed_date = $3,
            streak_count = $4
        WHERE id = $5
      `, [completedAt, photoUrl, today, newStreakCount, taskId]);
      
      // Get updated task
      const updatedResult = await pool.query('SELECT * FROM daily_tasks WHERE id = $1', [taskId]);
      res.json(updatedResult.rows[0]);
    } catch (error: any) {
      res.status(500).json({ message: 'Failed to upload photo', error: error.message });
    }
  });

  // Start time estimation challenge
  app.post('/api/daily-tasks/:id/start-challenge', async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const { estimatedMinutes } = req.body;

      if (!estimatedMinutes || estimatedMinutes <= 0) {
        return res.status(400).json({ message: 'Valid estimated time is required' });
      }

      const startedAt = new Date().toISOString();
      
      await pool.query(`
        UPDATE daily_tasks 
        SET estimated_minutes = $1, started_at = $2
        WHERE id = $3
      `, [estimatedMinutes, startedAt, taskId]);

      const result = await pool.query('SELECT * FROM daily_tasks WHERE id = $1', [taskId]);
      if (result.rows.length === 0) {
        return res.status(404).json({ message: 'Task not found' });
      }

      res.json(result.rows[0]);
    } catch (error: any) {
      res.status(500).json({ message: 'Failed to start time challenge', error: error.message });
    }
  });

  // Complete task with photo and calculate estimation points
  app.post('/api/daily-tasks/:id/complete-challenge', upload.single('photo'), async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      
      if (!req.file) {
        return res.status(400).json({ message: 'No photo uploaded' });
      }

      const photoUrl = `/api/uploads/${req.file.filename}`;
      const completedAt = new Date().toISOString();
      const today = new Date().toISOString().split('T')[0];
      
      // Get current task
      const taskResult = await pool.query('SELECT * FROM daily_tasks WHERE id = $1', [taskId]);
      if (taskResult.rows.length === 0) {
        return res.status(404).json({ message: 'Task not found' });
      }
      
      const task = taskResult.rows[0];
      let actualMinutes = 0;
      let estimationPoints = 0;

      // Calculate actual time if task was started
      if (task.started_at) {
        const startTime = new Date(task.started_at);
        const endTime = new Date();
        actualMinutes = Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60));

        // Calculate estimation points based on accuracy
        if (task.estimated_minutes) {
          const accuracy = Math.abs(task.estimated_minutes - actualMinutes);
          const accuracyPercentage = Math.max(0, 100 - (accuracy / task.estimated_minutes * 100));
          
          // Point system: Perfect estimate = 100 points, scaling down
          if (accuracyPercentage >= 90) estimationPoints = 100;
          else if (accuracyPercentage >= 80) estimationPoints = 75;
          else if (accuracyPercentage >= 70) estimationPoints = 50;
          else if (accuracyPercentage >= 60) estimationPoints = 25;
          else if (accuracyPercentage >= 50) estimationPoints = 10;
          
          // Bonus points for consistency
          if (accuracy <= 2) estimationPoints += 50; // Within 2 minutes
          if (accuracy <= 1) estimationPoints += 25; // Within 1 minute
        }
      }

      // Handle streak calculation
      let newStreakCount = task.streak_count || 0;
      if (task.recurring && task.last_completed_date !== today) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().split('T')[0];
        
        if (task.last_completed_date === yesterdayStr) {
          newStreakCount += 1;
        } else {
          newStreakCount = 1;
        }
      }
      
      // Update task with all completion data
      await pool.query(`
        UPDATE daily_tasks 
        SET is_completed = true, 
            completed_at = $1, 
            photo_url = $2,
            last_completed_date = $3,
            streak_count = $4,
            actual_minutes = $5,
            estimation_points = $6
        WHERE id = $7
      `, [completedAt, photoUrl, today, newStreakCount, actualMinutes, estimationPoints, taskId]);
      
      const updatedResult = await pool.query('SELECT * FROM daily_tasks WHERE id = $1', [taskId]);
      res.json(updatedResult.rows[0]);
    } catch (error: any) {
      res.status(500).json({ message: 'Failed to complete challenge', error: error.message });
    }
  });

  // Get estimation challenge stats for a user
  app.get('/api/estimation-stats/:userId', async (req, res) => {
    try {
      const userId = req.params.userId;
      
      const result = await pool.query(`
        SELECT * FROM daily_tasks 
        WHERE assigned_to = $1 
        AND estimated_minutes IS NOT NULL 
        AND actual_minutes IS NOT NULL 
        AND is_completed = true
        ORDER BY completed_at DESC
      `, [userId]);

      const userTasks = result.rows;
      const totalPoints = userTasks.reduce((sum, task) => sum + (task.estimation_points || 0), 0);
      const totalChallenges = userTasks.length;
      const averageAccuracy = totalChallenges > 0 
        ? userTasks.reduce((sum, task) => {
            const accuracy = Math.abs(task.estimated_minutes - task.actual_minutes);
            return sum + Math.max(0, 100 - (accuracy / task.estimated_minutes * 100));
          }, 0) / totalChallenges
        : 0;

      const perfectEstimates = userTasks.filter(task => 
        Math.abs(task.estimated_minutes - task.actual_minutes) <= 1
      ).length;

      res.json({
        totalPoints,
        totalChallenges,
        averageAccuracy: Math.round(averageAccuracy),
        perfectEstimates,
        recentChallenges: userTasks.slice(0, 5)
      });
    } catch (error: any) {
      res.status(500).json({ message: 'Failed to fetch estimation stats', error: error.message });
    }
  });

  // Delete a daily task
  app.delete('/api/daily-tasks/:id', async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const deleted = await storage.deleteDailyTask(taskId);
      
      if (!deleted) {
        return res.status(404).json({ message: 'Task not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete task' });
    }
  });

  // Get all payments
  app.get('/api/payments', async (req, res) => {
    try {
      const payments = await storage.getAllPayments();
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch payments' });
    }
  });

  // Create a payment
  app.post('/api/payments', async (req, res) => {
    try {
      const paymentData = insertPaymentSchema.parse(req.body);
      const payment = await storage.createPayment(paymentData);
      res.status(201).json(payment);
    } catch (error) {
      res.status(400).json({ message: 'Invalid payment data', error: error.message });
    }
  });

  // Get statistics
  app.get('/api/stats', async (req, res) => {
    try {
      const tasks = await storage.getAllDailyTasks();
      const payments = await storage.getAllPayments();
      
      const totalTasks = tasks.length;
      const completedToday = tasks.filter(task => {
        if (!task.completedAt) return false;
        const completedDate = new Date(task.completedAt).toDateString();
        const today = new Date().toDateString();
        return completedDate === today;
      }).length;

      const weekStart = new Date();
      weekStart.setDate(weekStart.getDate() - weekStart.getDay());
      weekStart.setHours(0, 0, 0, 0);
      
      const weeklyEarnings = tasks
        .filter(task => task.isCompleted && task.completedAt && new Date(task.completedAt) >= weekStart)
        .reduce((sum, task) => sum + (task.value || 0), 0);

      res.json({
        totalTasks,
        completedToday,
        weeklyEarnings: weeklyEarnings / 100 // Convert cents to dollars
      });
    } catch (error: any) {
      res.status(500).json({ message: 'Failed to fetch statistics', error: error.message });
    }
  });

  // Manual chore rotation endpoint (for parents)
  app.post('/api/rotate-chores', async (req, res) => {
    try {
      await rotateWeeklyChores();
      res.json({ message: 'Chores rotated successfully!' });
    } catch (error: any) {
      res.status(500).json({ message: 'Failed to rotate chores', error: error.message });
    }
  });

  // Get allowance summary
  app.get('/api/allowance', async (req, res) => {
    try {
      const tasks = await storage.getAllDailyTasks();
      const payments = await storage.getAllPayments();
      
      const familyMembers = ['Emma', 'Alex', 'Sarah', 'Jake'];
      const allowanceSummary = familyMembers.map(member => {
        const memberTasks = tasks.filter(task => task.assignedTo === member && task.isCompleted && task.value && task.value > 0);
        const memberPayments = payments.filter(payment => payment.recipientName === member);
        
        const totalEarned = memberTasks.reduce((sum, task) => sum + (task.value || 0), 0);
        const totalPaid = memberPayments.reduce((sum, payment) => sum + payment.amount, 0);
        
        return {
          name: member,
          initials: member.charAt(0),
          completedChores: memberTasks.length,
          totalEarned: totalEarned / 100, // Convert to dollars
          totalPaid: totalPaid / 100, // Convert to dollars
          outstanding: (totalEarned - totalPaid) / 100 // Convert to dollars
        };
      });

      res.json(allowanceSummary);
    } catch (error: any) {
      res.status(500).json({ message: 'Failed to fetch allowance data', error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
