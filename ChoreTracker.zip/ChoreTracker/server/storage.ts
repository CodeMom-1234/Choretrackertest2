import { dailyTasks, payments, type DailyTask, type InsertDailyTask, type Payment, type InsertPayment } from "@shared/schema";
import { db } from "./db";
import { eq, asc } from "drizzle-orm";

export interface IStorage {
  getAllDailyTasks(): Promise<DailyTask[]>;
  getDailyTask(id: number): Promise<DailyTask | undefined>;
  createDailyTask(task: InsertDailyTask): Promise<DailyTask>;
  updateDailyTask(id: number, updates: Partial<DailyTask>): Promise<DailyTask | undefined>;
  deleteDailyTask(id: number): Promise<boolean>;
  
  getAllPayments(): Promise<Payment[]>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPaymentsByRecipient(recipientName: string): Promise<Payment[]>;
}

export class DatabaseStorage implements IStorage {


  async getAllDailyTasks(): Promise<DailyTask[]> {
    try {
      const result = await db.select().from(dailyTasks);
      return result;
    } catch (error) {
      console.error('Database error in getAllDailyTasks:', error);
      throw error;
    }
  }

  async getDailyTask(id: number): Promise<DailyTask | undefined> {
    const [task] = await db.select().from(dailyTasks).where(eq(dailyTasks.id, id));
    return task || undefined;
  }

  async createDailyTask(insertTask: InsertDailyTask): Promise<DailyTask> {
    const [task] = await db
      .insert(dailyTasks)
      .values(insertTask)
      .returning();
    return task;
  }

  async updateDailyTask(id: number, updates: Partial<DailyTask>): Promise<DailyTask | undefined> {
    const [updatedTask] = await db
      .update(dailyTasks)
      .set(updates)
      .where(eq(dailyTasks.id, id))
      .returning();
    return updatedTask || undefined;
  }

  async deleteDailyTask(id: number): Promise<boolean> {
    const result = await db
      .delete(dailyTasks)
      .where(eq(dailyTasks.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getAllPayments(): Promise<Payment[]> {
    return await db.select().from(payments).orderBy(payments.paidAt);
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const [payment] = await db
      .insert(payments)
      .values({
        ...insertPayment,
        paidAt: new Date().toISOString()
      })
      .returning();
    return payment;
  }

  async getPaymentsByRecipient(recipientName: string): Promise<Payment[]> {
    return await db.select().from(payments)
      .where(eq(payments.recipientName, recipientName))
      .orderBy(payments.paidAt);
  }
}

export const storage = new DatabaseStorage();
