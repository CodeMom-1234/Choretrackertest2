import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface User {
  id: number;
  username: string;
  displayName: string;
  role: "parent" | "child";
}

export function useAuth() {
  const queryClient = useQueryClient();

  // Get session token from localStorage
  const getSessionToken = () => localStorage.getItem('sessionToken');
  const setSessionToken = (token: string) => localStorage.setItem('sessionToken', token);
  const clearSessionToken = () => localStorage.removeItem('sessionToken');

  // Configure the default query with auth headers
  const { data: user, isLoading, error } = useQuery<User>({
    queryKey: ['/api/auth/user'],
    queryFn: async () => {
      const token = getSessionToken();
      if (!token) throw new Error('No session');
      
      const response = await fetch('/api/auth/user', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        clearSessionToken();
        throw new Error('Authentication failed');
      }
      
      return response.json();
    },
    retry: false,
    enabled: !!getSessionToken(),
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const token = getSessionToken();
      if (token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
      }
      clearSessionToken();
    },
    onSuccess: () => {
      queryClient.clear();
    },
  });

  const login = (sessionId: string, userData: User) => {
    setSessionToken(sessionId);
    queryClient.setQueryData(['/api/auth/user'], userData);
  };

  const logout = () => {
    logoutMutation.mutate();
  };

  return {
    user,
    isLoading,
    isAuthenticated: !!user && !error,
    login,
    logout,
    getSessionToken,
  };
}