import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { CreditCard, DollarSign, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface AllowanceMember {
  name: string;
  initials: string;
  completedChores: number;
  totalEarned: number;
  totalPaid: number;
  outstanding: number;
}

interface Payment {
  id: number;
  recipientName: string;
  amount: number;
  description: string;
  paidAt: string;
  choreId?: number;
}

export default function AllowanceTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: allowanceData, isLoading: allowanceLoading } = useQuery<AllowanceMember[]>({
    queryKey: ['/api/allowance'],
  });

  const { data: payments, isLoading: paymentsLoading } = useQuery<Payment[]>({
    queryKey: ['/api/payments'],
  });



  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      if (diffInHours < 1) return 'Just now';
      return `${diffInHours}h ago`;
    }
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays === 1) return 'Yesterday';
    if (diffInDays < 7) return `${diffInDays} days ago`;
    
    return date.toLocaleDateString();
  };

  if (allowanceLoading || paymentsLoading) {
    return <div>Loading...</div>;
  }

  const totalOutstanding = allowanceData?.reduce((sum, member) => sum + member.outstanding, 0) || 0;
  const recentPayments = payments?.slice(0, 5) || [];

  return (
    <div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Family Members Allowance */}
        <Card className="border border-gray-100">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Allowance Summary</h2>
            <p className="text-sm text-gray-500 mt-1">Current week earnings and payments</p>
          </div>

          <CardContent className="p-6 space-y-6">
            {allowanceData?.map((member) => (
              <div key={member.name} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold">{member.initials}</span>
                  </div>
                  <div className="ml-4">
                    <h3 className="font-medium text-gray-900">{member.name}</h3>
                    <p className="text-sm text-gray-500">
                      {member.completedChores} chores completed
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-gray-900">${member.totalEarned.toFixed(2)}</p>
                  <p className="text-sm text-gray-500">
                    Paid: <span className="text-secondary font-medium">${member.totalPaid.toFixed(2)}</span>
                  </p>
                  {member.outstanding > 0 && (
                    <p className="text-sm font-medium text-accent">
                      Outstanding: ${member.outstanding.toFixed(2)}
                    </p>
                  )}
                  {member.outstanding === 0 && member.totalEarned > 0 && (
                    <p className="text-sm font-medium text-secondary">
                      ✓ All Paid Up!
                    </p>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Outstanding Summary */}
        <Card className="border border-gray-100">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Amounts Owed</h2>
            <p className="text-sm text-gray-500 mt-1">Total allowances to pay out</p>
          </div>

          <CardContent className="p-6 space-y-4">
            {allowanceData?.map((member) => (
              member.outstanding > 0 && (
                <div key={member.name} className="p-4 border border-gray-200 rounded-lg bg-accent/5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-accent/10 rounded-full flex items-center justify-center">
                        <span className="text-accent font-semibold">{member.initials}</span>
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium text-gray-900">{member.name}</h3>
                        <p className="text-sm text-gray-500">{member.completedChores} chores completed</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl font-bold text-accent">${member.outstanding.toFixed(2)}</span>
                      <p className="text-sm text-gray-500">owed</p>
                    </div>
                  </div>
                </div>
              )
            ))}

            {totalOutstanding > 0 ? (
              <div className="pt-4 border-t border-gray-200">
                <div className="bg-primary/5 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">Total Amount Owed</h3>
                    <span className="text-3xl font-bold text-primary">${totalOutstanding.toFixed(2)}</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">Total allowances for all family members</p>
                </div>
              </div>
            ) : (
              <div className="text-center py-6">
                <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Check className="text-secondary h-8 w-8" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">All Caught Up!</h3>
                <p className="text-gray-500">No outstanding allowances at the moment</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Payment History */}
      <Card className="mt-8 border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Recent Payments</h2>
          <p className="text-sm text-gray-500 mt-1">Payment history and transaction records</p>
        </div>

        <div className="divide-y divide-gray-100">
          {recentPayments.length > 0 ? (
            recentPayments.map((payment) => (
              <div key={payment.id} className="p-6 flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center">
                    <Check className="text-secondary h-5 w-5" />
                  </div>
                  <div className="ml-4">
                    <h3 className="font-medium text-gray-900">{payment.recipientName}</h3>
                    <p className="text-sm text-gray-500">{payment.description}</p>
                    <div className="flex items-center mt-1">
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary/10 text-secondary">
                        ✓ Paid
                      </span>
                      <span className="ml-2 text-xs text-gray-400">
                        {new Date(payment.paidAt).toLocaleDateString()} at {new Date(payment.paidAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">${(payment.amount / 100).toFixed(2)}</p>
                  <p className="text-sm text-gray-500">{formatTimeAgo(payment.paidAt)}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="p-6 text-center text-gray-500">
              No payments yet
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
