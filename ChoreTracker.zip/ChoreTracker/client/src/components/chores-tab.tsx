import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Camera, Clock, User, DollarSign, ListTodo, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useState, useRef } from "react";

interface Chore {
  id: number;
  title: string;
  description: string;
  assignedTo: string;
  value: number;
  dueDate: string;
  isCompleted: boolean;
  completedAt: string | null;
  photoUrl: string | null;
  icon: string;
}

interface Stats {
  totalChores: number;
  completedToday: number;
  weeklyEarnings: number;
}

export default function ChoresTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [uploadingChoreId, setUploadingChoreId] = useState<number | null>(null);
  const fileInputRefs = useRef<{ [key: number]: HTMLInputElement | null }>({});

  const { data: chores, isLoading: choresLoading } = useQuery<Chore[]>({
    queryKey: ['/api/chores'],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<Stats>({
    queryKey: ['/api/stats'],
  });

  const uploadPhotoMutation = useMutation({
    mutationFn: async ({ choreId, file }: { choreId: number; file: File }) => {
      const formData = new FormData();
      formData.append('photo', file);
      
      const response = await fetch(`/api/chores/${choreId}/photo`, {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to upload photo');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chores'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      setUploadingChoreId(null);
      toast({
        title: "Success!",
        description: "Photo uploaded and chore marked as completed.",
      });
    },
    onError: () => {
      setUploadingChoreId(null);
      toast({
        title: "Error",
        description: "Failed to upload photo. Please try again.",
        variant: "destructive",
      });
    },
  });

  const approveMutation = useMutation({
    mutationFn: async (choreId: number) => {
      const chore = chores?.find(c => c.id === choreId);
      if (!chore) throw new Error('Chore not found');
      
      // Create payment for the chore
      await apiRequest('POST', '/api/payments', {
        recipientName: chore.assignedTo,
        amount: chore.value,
        description: `Payment for: ${chore.title}`,
        choreId: choreId,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/payments'] });
      toast({
        title: "Payment Processed!",
        description: "Allowance payment has been approved and processed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to process payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = async (choreId: number, file: File) => {
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file",
        description: "Please select an image file.",
        variant: "destructive",
      });
      return;
    }

    setUploadingChoreId(choreId);
    uploadPhotoMutation.mutate({ choreId, file });
  };

  const triggerFileInput = (choreId: number) => {
    fileInputRefs.current[choreId]?.click();
  };

  const getIconColorClass = (icon: string) => {
    if (icon.includes('broom')) return 'bg-blue-100 text-blue-600';
    if (icon.includes('utensils')) return 'bg-green-100 text-green-600';
    if (icon.includes('bed')) return 'bg-purple-100 text-purple-600';
    return 'bg-gray-100 text-gray-600';
  };

  const formatDueDate = (dueDate: string) => {
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    
    if (dueDate === today) return 'Due Today';
    if (dueDate === tomorrow) return 'Due Tomorrow';
    return `Due ${new Date(dueDate).toLocaleDateString()}`;
  };

  if (choresLoading || statsLoading) {
    return <div>Loading...</div>;
  }

  const activeChores = chores?.filter(chore => !chore.isCompleted) || [];
  const completedUnpaidChores = chores?.filter(chore => chore.isCompleted) || [];

  return (
    <div>
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="border border-gray-100">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-primary/10">
                <ListTodo className="text-primary text-xl" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Total Chores</h3>
                <p className="text-2xl font-bold text-gray-900">{stats?.totalChores || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-100">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-secondary/10">
                <CheckCircle className="text-secondary text-xl" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Completed Today</h3>
                <p className="text-2xl font-bold text-gray-900">{stats?.completedToday || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-100">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-accent/10">
                <DollarSign className="text-accent text-xl" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Earned This Week</h3>
                <p className="text-2xl font-bold text-gray-900">${stats?.weeklyEarnings?.toFixed(2) || '0.00'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Chores List */}
      <Card className="border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Active Chores</h2>
          <p className="text-sm text-gray-500 mt-1">Complete tasks and upload photos for verification</p>
        </div>

        <div className="divide-y divide-gray-100">
          {activeChores.map((chore) => (
            <div key={chore.id} className="p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${getIconColorClass(chore.icon)}`}>
                    <i className={chore.icon}></i>
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-medium text-gray-900">{chore.title}</h3>
                    <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
                      <DollarSign className="mr-1 h-3 w-3" />
                      ${(chore.value / 100).toFixed(2)}
                    </Badge>
                  </div>
                  
                  <p className="text-sm text-gray-500 mt-1">{chore.description}</p>
                  
                  <div className="flex items-center mt-3 text-xs text-gray-400">
                    <User className="mr-1 h-3 w-3" />
                    <span>{chore.assignedTo}</span>
                    <Clock className="ml-4 mr-1 h-3 w-3" />
                    <span>{formatDueDate(chore.dueDate)}</span>
                  </div>
                  
                  {/* Photo Upload Area */}
                  <div 
                    className="mt-4 p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-primary transition-colors cursor-pointer"
                    onClick={() => triggerFileInput(chore.id)}
                  >
                    <input
                      ref={(el) => fileInputRefs.current[chore.id] = el}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          handleFileSelect(chore.id, file);
                        }
                      }}
                    />
                    <div className="text-center">
                      {uploadingChoreId === chore.id ? (
                        <div className="text-primary">
                          <div className="animate-spin inline-block w-6 h-6 border-2 border-current border-t-transparent rounded-full mb-2"></div>
                          <p className="text-sm text-primary">Uploading...</p>
                        </div>
                      ) : (
                        <>
                          <Camera className="text-gray-400 text-2xl mb-2 mx-auto" />
                          <p className="text-sm text-gray-600">Upload completion photo</p>
                          <p className="text-xs text-gray-400 mt-1">Drag & drop or click to browse</p>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {completedUnpaidChores.map((chore) => (
            <div key={chore.id} className="p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${getIconColorClass(chore.icon)}`}>
                    <i className={chore.icon}></i>
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-medium text-gray-900">{chore.title}</h3>
                    <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
                      <DollarSign className="mr-1 h-3 w-3" />
                      ${(chore.value / 100).toFixed(2)}
                    </Badge>
                  </div>
                  
                  <p className="text-sm text-gray-500 mt-1">{chore.description}</p>
                  
                  <div className="flex items-center mt-3 text-xs text-gray-400">
                    <User className="mr-1 h-3 w-3" />
                    <span>{chore.assignedTo}</span>
                    <Clock className="ml-4 mr-1 h-3 w-3" />
                    <span>{formatDueDate(chore.dueDate)}</span>
                  </div>
                  
                  {/* Completed Task Display */}
                  <div className="mt-4 p-4 bg-secondary/5 border border-secondary/20 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <CheckCircle className="text-secondary mr-2 h-5 w-5" />
                        <span className="text-sm font-medium text-secondary">Task Completed!</span>
                      </div>
                      {chore.photoUrl && (
                        <img 
                          src={chore.photoUrl} 
                          alt="Completed task verification" 
                          className="w-16 h-16 rounded-lg object-cover border border-gray-200" 
                        />
                      )}
                    </div>
                    <Button 
                      onClick={() => approveMutation.mutate(chore.id)}
                      disabled={approveMutation.isPending}
                      className="mt-3 bg-secondary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-secondary/90 transition-colors"
                    >
                      <DollarSign className="mr-1 h-4 w-4" />
                      {approveMutation.isPending ? 'Processing...' : `Approve & Pay $${(chore.value / 100).toFixed(2)}`}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
