import { useQuery } from "@tanstack/react-query";
import { CheckCircle, User, Calendar, DollarSign } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Chore {
  id: number;
  title: string;
  description: string;
  assignedTo: string;
  value: number;
  dueDate: string;
  isCompleted: boolean;
  completedAt: string | null;
  photoUrl: string | null;
  icon: string;
}

export default function CompletedTab() {
  const { data: chores, isLoading } = useQuery<Chore[]>({
    queryKey: ['/api/chores'],
  });

  const getIconColorClass = (icon: string) => {
    if (icon.includes('broom')) return 'bg-blue-100 text-blue-600';
    if (icon.includes('utensils')) return 'bg-green-100 text-green-600';
    if (icon.includes('bed')) return 'bg-purple-100 text-purple-600';
    if (icon.includes('trash')) return 'bg-red-100 text-red-600';
    if (icon.includes('vacuum')) return 'bg-indigo-100 text-indigo-600';
    return 'bg-gray-100 text-gray-600';
  };

  const formatCompletedTime = (completedAt: string) => {
    const date = new Date(completedAt);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      if (diffInHours < 1) return 'Completed just now';
      return `Completed ${diffInHours}h ago`;
    }
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays === 1) return 'Completed yesterday';
    if (diffInDays < 7) return `Completed ${diffInDays} days ago`;
    
    return `Completed on ${date.toLocaleDateString()}`;
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  const completedChores = chores?.filter(chore => chore.isCompleted) || [];

  return (
    <Card className="border border-gray-100">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">Completed Chores</h2>
        <p className="text-sm text-gray-500 mt-1">History of completed tasks with verification photos</p>
      </div>

      <div className="divide-y divide-gray-100">
        {completedChores.length > 0 ? (
          completedChores.map((chore) => (
            <div key={chore.id} className="p-6">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center">
                    <CheckCircle className="text-secondary text-xl" />
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-medium text-gray-900">{chore.title}</h3>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="bg-secondary/10 text-secondary border-secondary/20">
                        <CheckCircle className="mr-1 h-3 w-3" />
                        Completed
                      </Badge>
                      <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
                        <DollarSign className="mr-1 h-3 w-3" />
                        ${(chore.value / 100).toFixed(2)}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex items-center mt-2 text-xs text-gray-400">
                    <User className="mr-1 h-3 w-3" />
                    <span>{chore.assignedTo}</span>
                    <Calendar className="ml-4 mr-1 h-3 w-3" />
                    <span>{chore.completedAt && formatCompletedTime(chore.completedAt)}</span>
                  </div>
                  
                  {chore.photoUrl && (
                    <div className="mt-4 flex items-center space-x-4">
                      <div className="flex-shrink-0">
                        <img 
                          src={chore.photoUrl} 
                          alt="Task verification photo" 
                          className="w-20 h-20 rounded-lg object-cover border border-gray-200" 
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-gray-600 font-medium">Verification Photo Submitted</p>
                        <p className="text-xs text-gray-400 mt-1">Photo shows completed task as requested</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="p-6 text-center text-gray-500">
            No completed chores yet
          </div>
        )}
      </div>
    </Card>
  );
}
