import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { X, Clock, Calendar } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const taskSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  assignedTo: z.string().min(1, "Please assign to someone"),
  taskType: z.string().min(1, "Task type is required"),
  value: z.string().min(1, "Payment amount is required"),
  scheduledTime: z.string().min(1, "Time is required"),
  icon: z.string().default("fas fa-tasks"),
  recurring: z.boolean().default(true),
  recurringDays: z.string().default("1,2,3,4,5,6,7"),
  alarmEnabled: z.boolean().default(false),
});

type TaskFormData = z.infer<typeof taskSchema>;

interface AddTaskModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const DAYS_OF_WEEK = [
  { id: 1, name: "Monday", short: "Mon" },
  { id: 2, name: "Tuesday", short: "Tue" },
  { id: 3, name: "Wednesday", short: "Wed" },
  { id: 4, name: "Thursday", short: "Thu" },
  { id: 5, name: "Friday", short: "Fri" },
  { id: 6, name: "Saturday", short: "Sat" },
  { id: 7, name: "Sunday", short: "Sun" },
];

const FREQUENCY_PRESETS = [
  { label: "Daily", days: [1, 2, 3, 4, 5, 6, 7] },
  { label: "Weekdays", days: [1, 2, 3, 4, 5] },
  { label: "Weekends", days: [6, 7] },
  { label: "Monday/Wednesday/Friday", days: [1, 3, 5] },
  { label: "Tuesday/Thursday", days: [2, 4] },
  { label: "Weekly (Mondays)", days: [1] },
  { label: "Custom", days: [] },
];

export default function AddTaskModal({ open, onOpenChange }: AddTaskModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedDays, setSelectedDays] = useState<number[]>([1, 2, 3, 4, 5, 6, 7]);
  const [selectedPreset, setSelectedPreset] = useState("Daily");

  const form = useForm<TaskFormData>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      title: "",
      description: "",
      assignedTo: "",
      taskType: "chore",
      value: "0",
      scheduledTime: "09:00",
      icon: "fas fa-tasks",
      recurring: true,
      recurringDays: "1,2,3,4,5,6,7",
      alarmEnabled: false,
    },
  });

  const createTaskMutation = useMutation({
    mutationFn: async (data: TaskFormData) => {
      const taskData = {
        ...data,
        value: Math.round(parseFloat(data.value) * 100), // Convert to cents
        recurringDays: selectedDays.join(","),
      };
      return apiRequest('POST', '/api/daily-tasks', taskData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      toast({
        title: "Success!",
        description: "Task created successfully",
      });
      onOpenChange(false);
      form.reset();
      setSelectedDays([1, 2, 3, 4, 5, 6, 7]);
      setSelectedPreset("Daily");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create task",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TaskFormData) => {
    if (selectedDays.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one day",
        variant: "destructive",
      });
      return;
    }
    createTaskMutation.mutate(data);
  };

  const handlePresetChange = (preset: string) => {
    setSelectedPreset(preset);
    const presetData = FREQUENCY_PRESETS.find(p => p.label === preset);
    if (presetData && presetData.days.length > 0) {
      setSelectedDays(presetData.days);
    }
  };

  const handleDayToggle = (dayId: number) => {
    setSelectedPreset("Custom");
    setSelectedDays(prev => 
      prev.includes(dayId) 
        ? prev.filter(d => d !== dayId)
        : [...prev, dayId].sort()
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Create New Task
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Basic Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Task Title</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Change bedding" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="assignedTo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assign to</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select family member" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Emma">Emma</SelectItem>
                        <SelectItem value="Alex">Alex</SelectItem>
                        <SelectItem value="Sarah">Sarah</SelectItem>
                        <SelectItem value="Jake">Jake</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="e.g., Strip bed, wash sheets, and remake with fresh bedding"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Task Type and Payment */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="taskType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Task Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="chore">🏠 Chore</SelectItem>
                        <SelectItem value="routine">⏰ Routine</SelectItem>
                        <SelectItem value="meal">🍽️ Meal</SelectItem>
                        <SelectItem value="activity">📚 Activity</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="value"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Amount ($)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.25" 
                        min="0"
                        placeholder="0.00"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="scheduledTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      Time
                    </FormLabel>
                    <FormControl>
                      <Input type="time" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Frequency Selection */}
            <Card>
              <CardContent className="p-4">
                <h3 className="font-medium mb-3">When should this task repeat?</h3>
                
                {/* Frequency Presets */}
                <div className="mb-4">
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Quick Presets:
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {FREQUENCY_PRESETS.map((preset) => (
                      <Button
                        key={preset.label}
                        type="button"
                        variant={selectedPreset === preset.label ? "default" : "outline"}
                        size="sm"
                        onClick={() => handlePresetChange(preset.label)}
                      >
                        {preset.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Custom Day Selection */}
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Select specific days:
                  </label>
                  <div className="grid grid-cols-7 gap-2">
                    {DAYS_OF_WEEK.map((day) => (
                      <div key={day.id} className="flex flex-col items-center">
                        <Checkbox
                          id={`day-${day.id}`}
                          checked={selectedDays.includes(day.id)}
                          onCheckedChange={() => handleDayToggle(day.id)}
                        />
                        <label 
                          htmlFor={`day-${day.id}`}
                          className="text-xs mt-1 cursor-pointer"
                        >
                          {day.short}
                        </label>
                      </div>
                    ))}
                  </div>
                  
                  {selectedDays.length > 0 && (
                    <p className="text-sm text-gray-600 mt-2">
                      This task will repeat on: {" "}
                      <span className="font-medium">
                        {selectedDays.map(dayId => 
                          DAYS_OF_WEEK.find(d => d.id === dayId)?.name
                        ).join(", ")}
                      </span>
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Submit Button */}
            <div className="flex justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createTaskMutation.isPending}
              >
                {createTaskMutation.isPending ? "Creating..." : "Create Task"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}