import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Timer, Trophy, Target, Zap, Award, Star, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface TimeEstimationChallengeProps {
  task: {
    id: number;
    title: string;
    assignedTo: string;
    estimatedMinutes?: number;
    startedAt?: string;
    actualMinutes?: number;
    estimationPoints?: number;
    isCompleted: boolean;
  };
  onChallengeComplete: () => void;
}

interface EstimationStats {
  totalPoints: number;
  totalChallenges: number;
  averageAccuracy: number;
  perfectEstimates: number;
  recentChallenges: any[];
}

export default function TimeEstimationChallenge({ task, onChallengeComplete }: TimeEstimationChallengeProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [estimatedTime, setEstimatedTime] = useState<number>(10);
  const [isRunning, setIsRunning] = useState(false);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [showStats, setShowStats] = useState(false);

  // Get user's estimation stats
  const { data: stats } = useQuery<EstimationStats>({
    queryKey: [`/api/estimation-stats/${task.assignedTo}`],
    enabled: showStats,
  });

  // Start challenge mutation
  const startChallengeMutation = useMutation({
    mutationFn: async (estimatedMinutes: number) => {
      return apiRequest('POST', `/api/daily-tasks/${task.id}/start-challenge`, {
        estimatedMinutes
      });
    },
    onSuccess: () => {
      setIsRunning(true);
      setElapsedTime(0);
      
      // Start timer
      const startTime = Date.now();
      const interval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startTime) / (1000 * 60));
        setElapsedTime(elapsed);
      }, 60000); // Update every minute

      // Store interval for cleanup
      (window as any).challengeInterval = interval;

      toast({
        title: "Challenge Started! ⏱️",
        description: `Good luck completing "${task.title}" in ${estimatedTime} minutes!`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start time challenge",
        variant: "destructive",
      });
    },
  });

  // Complete challenge with photo
  const completeChallengeWithPhoto = async (file: File) => {
    try {
      // Clear timer
      if ((window as any).challengeInterval) {
        clearInterval((window as any).challengeInterval);
        (window as any).challengeInterval = null;
      }

      const formData = new FormData();
      formData.append('photo', file);
      
      const response = await fetch(`/api/daily-tasks/${task.id}/complete-challenge`, {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Upload failed');
      }
      
      const result = await response.json();
      
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      queryClient.invalidateQueries({ queryKey: [`/api/estimation-stats/${task.assignedTo}`] });
      
      // Show completion results
      const pointsEarned = result.estimation_points || 0;
      const actualTime = result.actual_minutes || 0;
      const estimatedTime = result.estimated_minutes || 0;
      const accuracy = Math.abs(estimatedTime - actualTime);

      let message = `Task completed in ${actualTime} minutes!`;
      if (pointsEarned > 0) {
        message += ` You earned ${pointsEarned} estimation points! 🎉`;
      }
      if (accuracy <= 1) {
        message += " Perfect estimate! 🎯";
      } else if (accuracy <= 2) {
        message += " Excellent estimate! ⭐";
      }

      toast({
        title: "Challenge Complete! 🏆",
        description: message,
      });

      setIsRunning(false);
      onChallengeComplete();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to complete challenge",
        variant: "destructive",
      });
    }
  };

  const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 90) return "text-green-600";
    if (accuracy >= 80) return "text-blue-600";
    if (accuracy >= 70) return "text-yellow-600";
    if (accuracy >= 60) return "text-orange-600";
    return "text-red-600";
  };

  const getPointsBadgeColor = (points: number) => {
    if (points >= 100) return "bg-purple-100 text-purple-800";
    if (points >= 75) return "bg-green-100 text-green-800";
    if (points >= 50) return "bg-blue-100 text-blue-800";
    if (points >= 25) return "bg-yellow-100 text-yellow-800";
    return "bg-gray-100 text-gray-800";
  };

  // If task is already completed, show results
  if (task.isCompleted && task.estimatedMinutes && task.actualMinutes) {
    const accuracy = Math.abs(task.estimatedMinutes - task.actualMinutes);
    const accuracyPercentage = Math.max(0, 100 - (accuracy / task.estimatedMinutes * 100));

    return (
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <Trophy className="h-5 w-5" />
            Challenge Complete!
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <p className="text-sm text-gray-600">Estimated Time</p>
              <p className="text-lg font-semibold">{task.estimatedMinutes} min</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Actual Time</p>
              <p className="text-lg font-semibold">{task.actualMinutes} min</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium">Accuracy</span>
            <span className={`font-bold ${getAccuracyColor(accuracyPercentage)}`}>
              {Math.round(accuracyPercentage)}%
            </span>
          </div>
          <Progress value={accuracyPercentage} className="mb-4" />
          
          {task.estimationPoints && task.estimationPoints > 0 && (
            <Badge className={getPointsBadgeColor(task.estimationPoints)}>
              <Star className="h-3 w-3 mr-1" />
              {task.estimationPoints} points earned!
            </Badge>
          )}

          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setShowStats(true)}
            className="mt-3 w-full"
          >
            <TrendingUp className="h-4 w-4 mr-2" />
            View My Stats
          </Button>
        </CardContent>
      </Card>
    );
  }

  // If challenge is running, show timer
  if (isRunning || task.startedAt) {
    return (
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <Timer className="h-5 w-5" />
            Challenge in Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-4">
            <p className="text-sm text-gray-600 mb-2">Target: {task.estimatedMinutes || estimatedTime} minutes</p>
            <p className="text-2xl font-bold text-blue-600">{elapsedTime} min elapsed</p>
            
            {elapsedTime > 0 && (
              <div className="mt-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-500">Progress</span>
                  <span className="text-xs text-gray-500">
                    {Math.round((elapsedTime / (task.estimatedMinutes || estimatedTime)) * 100)}%
                  </span>
                </div>
                <Progress 
                  value={(elapsedTime / (task.estimatedMinutes || estimatedTime)) * 100} 
                  className="h-2"
                />
              </div>
            )}
          </div>
          
          <div className="space-y-2">
            <p className="text-sm text-gray-600 text-center">
              Complete the task and upload a photo to finish the challenge!
            </p>
            
            <label className="block">
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    completeChallengeWithPhoto(file);
                  }
                }}
                className="hidden"
              />
              <Button className="w-full">
                <Trophy className="h-4 w-4 mr-2" />
                Upload Completion Photo
              </Button>
            </label>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Start challenge interface
  return (
    <>
      <Card className="border-yellow-200 bg-yellow-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-yellow-800">
            <Target className="h-5 w-5" />
            Time Estimation Challenge
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600 mb-3">
                How long do you think "{task.title}" will take to complete?
              </p>
              
              <div className="flex items-center space-x-2">
                <Input
                  type="number"
                  min="1"
                  max="180"
                  value={estimatedTime}
                  onChange={(e) => setEstimatedTime(parseInt(e.target.value) || 1)}
                  className="w-20"
                />
                <span className="text-sm text-gray-600">minutes</span>
              </div>
            </div>
            
            <div className="bg-white p-3 rounded-lg border">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="h-4 w-4 text-yellow-600" />
                <span className="font-medium text-sm">Point System</span>
              </div>
              <div className="text-xs text-gray-600 space-y-1">
                <p>• Perfect estimate (±1 min): 125+ points</p>
                <p>• Excellent (±2 min): 100+ points</p>
                <p>• Good (90%+ accuracy): 100 points</p>
                <p>• Decent (80%+ accuracy): 75 points</p>
                <p>• Fair (70%+ accuracy): 50 points</p>
              </div>
            </div>
            
            <Button 
              onClick={() => startChallengeMutation.mutate(estimatedTime)}
              disabled={startChallengeMutation.isPending}
              className="w-full"
            >
              <Timer className="h-4 w-4 mr-2" />
              {startChallengeMutation.isPending ? "Starting..." : "Start Challenge"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats Modal */}
      {showStats && stats && (
        <Card className="mt-4 border-purple-200 bg-purple-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-800">
              <Award className="h-5 w-5" />
              {task.assignedTo}'s Estimation Stats
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">{stats.totalPoints}</p>
                <p className="text-sm text-gray-600">Total Points</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{stats.averageAccuracy}%</p>
                <p className="text-sm text-gray-600">Avg Accuracy</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{stats.perfectEstimates}</p>
                <p className="text-sm text-gray-600">Perfect Estimates</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-orange-600">{stats.totalChallenges}</p>
                <p className="text-sm text-gray-600">Total Challenges</p>
              </div>
            </div>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setShowStats(false)}
              className="w-full"
            >
              Close Stats
            </Button>
          </CardContent>
        </Card>
      )}
    </>
  );
}