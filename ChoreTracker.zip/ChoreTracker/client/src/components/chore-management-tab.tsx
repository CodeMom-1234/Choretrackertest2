import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { 
  DollarSign, 
  Clock, 
  Calendar,
  Edit,
  Save,
  X,
  Plus,
  Trash2,
  RotateCcw,
  Users
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DailyTask {
  id: number;
  title: string;
  description: string;
  assignedTo: string;
  taskType: string;
  scheduledTime: string;
  value: number;
  isCompleted: boolean;
  completedAt: string | null;
  photoUrl: string | null;
  icon: string;
  alarmEnabled: boolean;
  recurring: boolean;
  lastCompletedDate: string | null;
  streakCount: number;
  recurringDays: string;
  isRotating: boolean;
  rotationGroup: string | null;
  rotationOrder: number;
}

const FAMILY_MEMBERS = ["Emma", "Alex", "Sarah", "Jake"];
const FAMILY_COLORS = {
  Emma: 'bg-pink-100 text-pink-800',
  Alex: 'bg-blue-100 text-blue-800',
  Sarah: 'bg-green-100 text-green-800',
  Jake: 'bg-yellow-100 text-yellow-800',
};

// Convert 24-hour to 12-hour format
const formatTimeTo12Hour = (time24: string) => {
  if (!time24) return "";
  const [hours, minutes] = time24.split(':');
  const hour = parseInt(hours);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${minutes} ${ampm}`;
};

export default function ChoreManagementTab() {
  const { toast } = useToast();
  const [editingChore, setEditingChore] = useState<number | null>(null);
  const [newChore, setNewChore] = useState({
    title: "",
    description: "",
    assignedTo: "",
    scheduledTime: "",
    value: "",
    recurringDays: "1,2,3,4,5,6,7"
  });
  const [showAddForm, setShowAddForm] = useState(false);
  const [bulkEditMode, setBulkEditMode] = useState(false);
  const [bulkEditData, setBulkEditData] = useState({
    choreName: "",
    newValue: "",
    newTime: "",
    applyToValue: false,
    applyToTime: false
  });

  const { data: tasks } = useQuery<DailyTask[]>({
    queryKey: ['/api/daily-tasks'],
  });

  // Filter only chores
  const chores = tasks?.filter(task => task.taskType === 'chore') || [];

  // Update chore mutation
  const updateChoreMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: any }) => {
      return await apiRequest("PATCH", `/api/daily-tasks/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      setEditingChore(null);
      toast({
        title: "Success",
        description: "Chore updated successfully!",
      });
    },
    onError: (error) => {
      console.error('Error updating chore:', error);
      toast({
        title: "Error",
        description: "Failed to update chore. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create chore mutation
  const createChoreMutation = useMutation({
    mutationFn: async (choreData: any) => {
      return await apiRequest("POST", "/api/daily-tasks", choreData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      setShowAddForm(false);
      setNewChore({
        title: "",
        description: "",
        assignedTo: "",
        scheduledTime: "",
        value: "",
        recurringDays: "1,2,3,4,5,6,7"
      });
      toast({
        title: "Success",
        description: "New chore created successfully!",
      });
    },
    onError: (error) => {
      console.error('Error creating chore:', error);
      toast({
        title: "Error",
        description: "Failed to create chore. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Delete chore mutation
  const deleteChoreMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/daily-tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      toast({
        title: "Success",
        description: "Chore deleted successfully!",
      });
    },
    onError: (error) => {
      console.error('Error deleting chore:', error);
      toast({
        title: "Error",
        description: "Failed to delete chore. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Bulk edit mutation
  const bulkEditMutation = useMutation({
    mutationFn: async ({ choreName, updates }: { choreName: string; updates: any }) => {
      // Find all tasks with the same title
      const matchingTasks = chores.filter(chore => chore.title === choreName);
      
      // Update each matching task
      const updatePromises = matchingTasks.map(task => 
        apiRequest("PATCH", `/api/daily-tasks/${task.id}`, updates)
      );
      
      return Promise.all(updatePromises);
    },
    onSuccess: (_, { choreName }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      setBulkEditMode(false);
      setBulkEditData({
        choreName: "",
        newValue: "",
        newTime: "",
        applyToValue: false,
        applyToTime: false
      });
      toast({
        title: "Success",
        description: `All "${choreName}" tasks updated successfully!`,
      });
    },
    onError: (error) => {
      console.error('Error bulk updating chores:', error);
      toast({
        title: "Error",
        description: "Failed to bulk update chores. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Merge duplicates mutation
  const mergeDuplicatesMutation = useMutation({
    mutationFn: async (choreName: string) => {
      const duplicates = chores.filter(chore => chore.title === choreName);
      if (duplicates.length <= 1) return;

      // Keep the first one, merge scheduling from others, then delete the rest
      const [keepTask, ...tasksToDelete] = duplicates;
      
      // Combine all recurring days from duplicates
      const allDays = new Set<string>();
      duplicates.forEach(task => {
        if (task.recurringDays) {
          task.recurringDays.split(',').forEach(day => allDays.add(day));
        }
      });
      
      // Update the kept task with combined schedule
      const updates = {
        recurringDays: Array.from(allDays).sort().join(',')
      };
      
      // Update the first task
      await apiRequest("PATCH", `/api/daily-tasks/${keepTask.id}`, updates);
      
      // Delete the duplicates
      const deletePromises = tasksToDelete.map(task => 
        apiRequest("DELETE", `/api/daily-tasks/${task.id}`)
      );
      
      await Promise.all(deletePromises);
      
      return { kept: keepTask, deleted: tasksToDelete.length };
    },
    onSuccess: (result, choreName) => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      toast({
        title: "Success",
        description: `Merged ${result?.deleted || 0} duplicate "${choreName}" tasks. Combined all schedules into one task.`,
      });
    },
    onError: (error) => {
      console.error('Error merging duplicates:', error);
      toast({
        title: "Error",
        description: "Failed to merge duplicates. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handle form submission for editing
  const handleUpdateChore = (id: number, formData: FormData) => {
    const updates = {
      title: formData.get('title'),
      description: formData.get('description'),
      assignedTo: formData.get('assignedTo'),
      scheduledTime: formData.get('scheduledTime'),
      value: Math.round(parseFloat(formData.get('value') as string || '0') * 100),
      recurringDays: formData.get('recurringDays'),
    };
    
    updateChoreMutation.mutate({ id, updates });
  };

  // Handle new chore creation
  const handleCreateChore = () => {
    if (!newChore.title || !newChore.assignedTo) {
      toast({
        title: "Error",
        description: "Please fill in title and assigned member.",
        variant: "destructive",
      });
      return;
    }

    const choreData = {
      ...newChore,
      taskType: 'chore',
      value: Math.round(parseFloat(newChore.value || '0') * 100),
      icon: 'Home',
      recurring: true,
      alarmEnabled: false,
    };

    createChoreMutation.mutate(choreData);
  };

  // Handle bulk edit
  const handleBulkEdit = () => {
    if (!bulkEditData.choreName) {
      toast({
        title: "Error",
        description: "Please select a chore to edit.",
        variant: "destructive",
      });
      return;
    }

    if (!bulkEditData.applyToValue && !bulkEditData.applyToTime) {
      toast({
        title: "Error",
        description: "Please select at least one field to update.",
        variant: "destructive",
      });
      return;
    }

    const updates: any = {};
    
    if (bulkEditData.applyToValue && bulkEditData.newValue) {
      updates.value = Math.round(parseFloat(bulkEditData.newValue) * 100);
    }
    
    if (bulkEditData.applyToTime && bulkEditData.newTime) {
      updates.scheduledTime = bulkEditData.newTime;
    }

    bulkEditMutation.mutate({ choreName: bulkEditData.choreName, updates });
  };

  // Format recurring days for display
  const formatRecurringDays = (days: string) => {
    const dayMap = ['', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return days.split(',').map(d => dayMap[parseInt(d)]).join(', ');
  };

  // Get duplicate chore groups
  const getDuplicates = () => {
    const choreGroups = chores.reduce((acc, chore) => {
      if (!acc[chore.title]) acc[chore.title] = [];
      acc[chore.title].push(chore);
      return acc;
    }, {} as Record<string, DailyTask[]>);

    return Object.entries(choreGroups).filter(([_, tasks]) => tasks.length > 1);
  };

  const duplicates = getDuplicates();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Chore Management</h2>
          <p className="text-gray-600">Manage chore schedules, payments, and assignments</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button 
            onClick={() => setBulkEditMode(!bulkEditMode)}
            variant={bulkEditMode ? "default" : "outline"}
            className="flex items-center space-x-2"
          >
            <Edit className="h-4 w-4" />
            <span>{bulkEditMode ? "Exit Bulk Edit" : "Bulk Edit"}</span>
          </Button>
          <Button 
            onClick={() => setShowAddForm(true)}
            className="flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Add New Chore</span>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">{chores.length}</p>
                <p className="text-sm text-gray-600">Total Chores</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-2xl font-bold">
                  ${((chores.reduce((sum, chore) => sum + (chore.value || 0), 0)) / 100).toFixed(2)}
                </p>
                <p className="text-sm text-gray-600">Daily Potential</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <RotateCcw className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">
                  {chores.filter(chore => chore.isRotating).length}
                </p>
                <p className="text-sm text-gray-600">Rotating Chores</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Calendar className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-2xl font-bold">
                  {chores.filter(chore => chore.recurring).length}
                </p>
                <p className="text-sm text-gray-600">Recurring Chores</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>



      {/* Bulk Edit Form */}
      {bulkEditMode && (
        <Card className="border-purple-200 bg-purple-50">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Bulk Edit Chores</span>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setBulkEditMode(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="bulk-chore-select">Select Chore Type</Label>
                <Select 
                  value={bulkEditData.choreName} 
                  onValueChange={(value) => setBulkEditData({...bulkEditData, choreName: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a chore to edit" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from(new Set(chores.map(chore => chore.title))).map(choreTitle => {
                      const choreCount = chores.filter(c => c.title === choreTitle).length;
                      return (
                        <SelectItem key={choreTitle} value={choreTitle}>
                          {choreTitle} ({choreCount} tasks)
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Switch 
                    checked={bulkEditData.applyToValue}
                    onCheckedChange={(checked) => setBulkEditData({...bulkEditData, applyToValue: checked})}
                  />
                  <Label htmlFor="bulk-value">Update Payment Amount</Label>
                </div>
                <Input
                  id="bulk-value"
                  type="number"
                  step="0.01"
                  min="0"
                  value={bulkEditData.newValue}
                  onChange={(e) => setBulkEditData({...bulkEditData, newValue: e.target.value})}
                  placeholder="0.00"
                  disabled={!bulkEditData.applyToValue}
                />
              </div>

              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Switch 
                    checked={bulkEditData.applyToTime}
                    onCheckedChange={(checked) => setBulkEditData({...bulkEditData, applyToTime: checked})}
                  />
                  <Label htmlFor="bulk-time">Update Time</Label>
                </div>
                <Input
                  id="bulk-time"
                  type="time"
                  value={bulkEditData.newTime}
                  onChange={(e) => setBulkEditData({...bulkEditData, newTime: e.target.value})}
                  disabled={!bulkEditData.applyToTime}
                />
              </div>
            </div>

            {bulkEditData.choreName && (
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-700">
                  This will update{" "}
                  <strong>{chores.filter(c => c.title === bulkEditData.choreName).length}</strong>{" "}
                  "{bulkEditData.choreName}" tasks
                  {bulkEditData.applyToValue && bulkEditData.newValue && (
                    <span> with payment amount of <strong>${bulkEditData.newValue}</strong></span>
                  )}
                  {bulkEditData.applyToTime && bulkEditData.newTime && (
                    <span> with time <strong>{formatTimeTo12Hour(bulkEditData.newTime)}</strong></span>
                  )}
                </p>
              </div>
            )}

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setBulkEditMode(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleBulkEdit}
                disabled={bulkEditMutation.isPending || !bulkEditData.choreName}
              >
                {bulkEditMutation.isPending ? "Updating..." : "Apply to All"}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add New Chore Form */}
      {showAddForm && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Add New Chore</span>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setShowAddForm(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="new-title">Chore Title</Label>
                <Input
                  id="new-title"
                  value={newChore.title}
                  onChange={(e) => setNewChore({...newChore, title: e.target.value})}
                  placeholder="e.g., Load dishwasher"
                />
              </div>
              <div>
                <Label htmlFor="new-assigned">Assigned To</Label>
                <Select 
                  value={newChore.assignedTo} 
                  onValueChange={(value) => setNewChore({...newChore, assignedTo: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select family member" />
                  </SelectTrigger>
                  <SelectContent>
                    {FAMILY_MEMBERS.map(member => (
                      <SelectItem key={member} value={member}>{member}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label htmlFor="new-description">Description</Label>
              <Textarea
                id="new-description"
                value={newChore.description}
                onChange={(e) => setNewChore({...newChore, description: e.target.value})}
                placeholder="Describe what needs to be done"
                rows={2}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="new-time">Scheduled Time</Label>
                <Input
                  id="new-time"
                  type="time"
                  value={newChore.scheduledTime}
                  onChange={(e) => setNewChore({...newChore, scheduledTime: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="new-value">Payment Amount ($)</Label>
                <Input
                  id="new-value"
                  type="number"
                  step="0.01"
                  min="0"
                  value={newChore.value}
                  onChange={(e) => setNewChore({...newChore, value: e.target.value})}
                  placeholder="0.00"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowAddForm(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleCreateChore}
                disabled={createChoreMutation.isPending}
              >
                {createChoreMutation.isPending ? "Creating..." : "Create Chore"}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Chores List */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">All Chores</h3>
        
        {chores.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No chores found. Add your first chore to get started!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {chores.map((chore) => (
              <Card key={chore.id} className="transition-all hover:shadow-md">
                <CardContent className="p-6">
                  {editingChore === chore.id ? (
                    <form 
                      onSubmit={(e) => {
                        e.preventDefault();
                        handleUpdateChore(chore.id, new FormData(e.currentTarget));
                      }}
                      className="space-y-4"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor={`title-${chore.id}`}>Title</Label>
                          <Input
                            id={`title-${chore.id}`}
                            name="title"
                            defaultValue={chore.title}
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor={`assignedTo-${chore.id}`}>Assigned To</Label>
                          <Select name="assignedTo" defaultValue={chore.assignedTo}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {FAMILY_MEMBERS.map(member => (
                                <SelectItem key={member} value={member}>{member}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor={`description-${chore.id}`}>Description</Label>
                        <Textarea
                          id={`description-${chore.id}`}
                          name="description"
                          defaultValue={chore.description}
                          rows={2}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor={`time-${chore.id}`}>Time</Label>
                          <Input
                            id={`time-${chore.id}`}
                            name="scheduledTime"
                            type="time"
                            defaultValue={chore.scheduledTime}
                          />
                        </div>
                        <div>
                          <Label htmlFor={`value-${chore.id}`}>Payment ($)</Label>
                          <Input
                            id={`value-${chore.id}`}
                            name="value"
                            type="number"
                            step="0.01"
                            min="0"
                            defaultValue={(chore.value / 100).toFixed(2)}
                          />
                        </div>
                        <div>
                          <Label htmlFor={`days-${chore.id}`}>Days</Label>
                          <Input
                            id={`days-${chore.id}`}
                            name="recurringDays"
                            defaultValue={chore.recurringDays}
                            placeholder="1,2,3,4,5,6,7"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end space-x-2">
                        <Button 
                          type="button"
                          variant="outline" 
                          onClick={() => setEditingChore(null)}
                        >
                          <X className="h-4 w-4 mr-2" />
                          Cancel
                        </Button>
                        <Button 
                          type="submit"
                          disabled={updateChoreMutation.isPending}
                        >
                          <Save className="h-4 w-4 mr-2" />
                          {updateChoreMutation.isPending ? "Saving..." : "Save"}
                        </Button>
                      </div>
                    </form>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h4 className="text-lg font-semibold">{chore.title}</h4>
                          <Badge className={FAMILY_COLORS[chore.assignedTo as keyof typeof FAMILY_COLORS] || 'bg-gray-100'}>
                            {chore.assignedTo}
                          </Badge>
                          {chore.value > 0 && (
                            <Badge variant="secondary">
                              <DollarSign className="h-3 w-3 mr-1" />
                              ${(chore.value / 100).toFixed(2)}
                            </Badge>
                          )}
                          {chore.isRotating && (
                            <Badge variant="outline">
                              <RotateCcw className="h-3 w-3 mr-1" />
                              Rotating
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-gray-600 mb-2">{chore.description}</p>
                        
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>{formatTimeTo12Hour(chore.scheduledTime)}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-4 w-4" />
                            <span>{formatRecurringDays(chore.recurringDays)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setEditingChore(chore.id)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteChoreMutation.mutate(chore.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}