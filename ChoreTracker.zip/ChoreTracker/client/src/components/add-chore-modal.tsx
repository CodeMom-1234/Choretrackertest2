import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { X } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const choreSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  assignedTo: z.string().min(1, "Please assign to someone"),
  taskType: z.string().min(1, "Task type is required"),
  value: z.string().min(1, "Payment amount is required"),
  scheduledTime: z.string().min(1, "Time is required"),
  icon: z.string().default("fas fa-tasks"),
  recurring: z.boolean().default(true),
  recurringDays: z.string().default("1,2,3,4,5,6,7"),
  alarmEnabled: z.boolean().default(false),
});

type ChoreFormData = z.infer<typeof choreSchema>;

interface AddChoreModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AddChoreModal({ open, onOpenChange }: AddChoreModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ChoreFormData>({
    resolver: zodResolver(choreSchema),
    defaultValues: {
      title: "",
      description: "",
      assignedTo: "",
      value: "",
      dueDate: "",
      icon: "fas fa-tasks",
    },
  });

  const createChoreMutation = useMutation({
    mutationFn: async (data: ChoreFormData) => {
      const choreData = {
        ...data,
        value: Math.round(parseFloat(data.value) * 100), // Convert to cents
      };
      return apiRequest('POST', '/api/chores', choreData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chores'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      form.reset();
      onOpenChange(false);
      toast({
        title: "Success!",
        description: "New chore has been added successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add chore. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ChoreFormData) => {
    createChoreMutation.mutate(data);
  };

  const familyMembers = ["Emma", "Alex"];
  const choreIcons = [
    { value: "fas fa-broom", label: "Cleaning" },
    { value: "fas fa-utensils", label: "Kitchen" },
    { value: "fas fa-bed", label: "Bedroom" },
    { value: "fas fa-trash", label: "Trash" },
    { value: "fas fa-car", label: "Car/Garage" },
    { value: "fas fa-seedling", label: "Garden" },
    { value: "fas fa-dog", label: "Pet Care" },
    { value: "fas fa-tasks", label: "General" },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md w-full p-6">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-semibold text-gray-900">Add New Chore</DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onOpenChange(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700">Chore Title</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g., Clean Kitchen" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700">Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      rows={3}
                      placeholder="Detailed instructions for the task"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="assignedTo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-gray-700">Assign To</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select member" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {familyMembers.map((member) => (
                          <SelectItem key={member} value={member}>
                            {member}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="value"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-gray-700">Payment</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                        <Input 
                          {...field} 
                          type="number" 
                          step="0.01"
                          min="0"
                          className="pl-8"
                          placeholder="5.00" 
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="dueDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700">Due Date</FormLabel>
                  <FormControl>
                    <Input {...field} type="date" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="icon"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700">Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {choreIcons.map((icon) => (
                        <SelectItem key={icon.value} value={icon.value}>
                          <div className="flex items-center">
                            <i className={`${icon.value} mr-2`}></i>
                            {icon.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex space-x-3 pt-4">
              <Button 
                type="button" 
                variant="outline"
                className="flex-1"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createChoreMutation.isPending}
                className="flex-1 bg-primary text-white hover:bg-primary/90"
              >
                {createChoreMutation.isPending ? 'Adding...' : 'Add Chore'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
