import { CheckCircle, DollarSign, ListTodo } from "lucide-react";

interface NavigationProps {
  activeTab: 'chores' | 'allowance' | 'completed';
  onTabChange: (tab: 'chores' | 'allowance' | 'completed') => void;
}

export default function Navigation({ activeTab, onTabChange }: NavigationProps) {
  const tabs = [
    { id: 'chores', label: 'Chores', icon: ListTodo },
    { id: 'allowance', label: 'Allowance', icon: DollarSign },
    { id: 'completed', label: 'Completed', icon: CheckCircle },
  ] as const;

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-16 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-8">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => onTabChange(id)}
              className={`border-b-2 py-4 px-1 font-medium transition-colors ${
                activeTab === id
                  ? 'border-primary text-primary'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Icon className="mr-2 h-4 w-4 inline" />
              {label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}
