import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Clock, Bell, Camera, CheckCircle, Sun, Moon, Coffee, UtensilsCrossed, BookOpen, Gamepad2, Dog, Home, Wind, Heart, Trash2, Droplets, Sparkles, Apple, Plus, Flame, RotateCcw, Calendar, User, Users } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import AddTaskModal from "@/components/add-task-modal";
import TimeEstimationChallenge from "@/components/time-estimation-challenge";

interface DailyTask {
  id: number;
  title: string;
  description: string;
  assignedTo: string;
  taskType: string;
  scheduledTime: string;
  value: number;
  isCompleted: boolean;
  completedAt: string | null;
  photoUrl: string | null;
  icon: string;
  alarmEnabled: boolean;
  recurring: boolean;
  lastCompletedDate: string | null;
  streakCount: number;
  recurringDays: string;
  isRotating: boolean;
  rotationGroup: string | null;
  rotationOrder: number;
  // Time estimation challenge fields
  estimatedMinutes?: number;
  actualMinutes?: number;
  startedAt?: string;
  estimationPoints?: number;
  gamificationEnabled?: boolean;
}

interface Stats {
  totalTasks: number;
  completedToday: number;
  weeklyEarnings: number;
}

const taskTypeColors = {
  routine: "bg-blue-100 text-blue-800",
  meal: "bg-green-100 text-green-800", 
  chore: "bg-yellow-100 text-yellow-800",
  activity: "bg-purple-100 text-purple-800"
};

const iconMap: { [key: string]: any } = {
  Clock, Bell, Camera, CheckCircle, Sun, Moon, Coffee, UtensilsCrossed, 
  BookOpen, Gamepad2, Dog, Home, Wind, Heart, Trash2, Droplets, Sparkles, Apple
};

export default function DailyScheduleTab() {
  const { toast } = useToast();
  const [selectedMember, setSelectedMember] = useState<string>("All");
  const [selectedTaskType, setSelectedTaskType] = useState<string>("All");
  const [showAddTask, setShowAddTask] = useState(false);
  const [editingTask, setEditingTask] = useState<DailyTask | null>(null);
  const [newTime, setNewTime] = useState<string>("");
  const [editingSchedule, setEditingSchedule] = useState<DailyTask | null>(null);
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const [showRecurringPrompt, setShowRecurringPrompt] = useState(false);
  const [pendingTimeUpdate, setPendingTimeUpdate] = useState<{ taskId: number; newTime: string; updateType?: 'today' | 'future' } | null>(null);
  const [userRole, setUserRole] = useState<"parent" | "child">("parent");
  
  const isParent = userRole === "parent";

  const { data: tasks, isLoading: tasksLoading, error } = useQuery<DailyTask[]>({
    queryKey: ['/api/daily-tasks'],
  });

  // Debug logging
  console.log('Tasks data:', tasks);
  console.log('Tasks loading:', tasksLoading);
  console.log('Tasks error:', error);

  const { data: stats, isLoading: statsLoading } = useQuery<Stats>({
    queryKey: ['/api/stats'],
  });

  const photoUploadMutation = useMutation({
    mutationFn: async ({ taskId, file }: { taskId: number; file: File }) => {
      const formData = new FormData();
      formData.append('photo', file);
      
      const response = await fetch(`/api/daily-tasks/${taskId}/photo`, {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Upload failed');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      toast({
        title: "Task Completed!",
        description: "Great job! Your streak is building.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload photo. Please try again.",
        variant: "destructive",
      });
    },
  });

  const editTimeMutation = useMutation({
    mutationFn: async ({ taskId, newTime, updateType }: { taskId: number; newTime: string; updateType?: 'today' | 'future' }) => {
      const response = await fetch(`/api/daily-tasks/${taskId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          scheduledTime: newTime,
          updateType: updateType || 'today'
        }),
      });
      if (!response.ok) throw new Error('Failed to update time');
      return response.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      setEditingTask(null);
      setNewTime("");
      setShowRecurringPrompt(false);
      setPendingTimeUpdate(null);
      toast({
        title: "Time Updated!",
        description: variables.updateType === 'future' 
          ? "Schedule updated for all future occurrences."
          : "Schedule updated for today only.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Could not update task time. Please try again.",
        variant: "destructive",
      });
    },
  });

  const editScheduleMutation = useMutation({
    mutationFn: async ({ taskId, days }: { taskId: number; days: number[] }) => {
      const response = await fetch(`/api/daily-tasks/${taskId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recurringDays: days.join(',') }),
      });
      if (!response.ok) throw new Error('Failed to update schedule');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      setEditingSchedule(null);
      setSelectedDays([]);
      toast({
        title: "Weekly Schedule Updated!",
        description: "Task days have been customized.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Could not update weekly schedule. Please try again.",
        variant: "destructive",
      });
    },
  });

  const rotateChoresMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/rotate-chores', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Failed to rotate chores');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      toast({
        title: "Chores Rotated!",
        description: "Weekly chore assignments have been updated.",
      });
    },
    onError: () => {
      toast({
        title: "Rotation Failed",
        description: "Could not rotate chores. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = async (taskId: number, file: File) => {
    photoUploadMutation.mutate({ taskId, file });
  };

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getRecurringDaysText = (recurringDays: string | null) => {
    if (!recurringDays) return 'Daily';
    const days = recurringDays.split(',').map(d => parseInt(d));
    const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    
    if (days.length === 7) return 'Daily';
    if (days.length === 5 && days.every(d => d <= 5)) return 'Weekdays';
    if (days.length === 2 && days.includes(6) && days.includes(7)) return 'Weekends';
    
    return days.map(d => dayNames[d - 1]).join(', ');
  };

  const getTimeStatus = (scheduledTime: string, isCompleted: boolean) => {
    const now = new Date();
    const [hours, minutes] = scheduledTime.split(':').map(Number);
    const scheduledDateTime = new Date();
    scheduledDateTime.setHours(hours, minutes, 0, 0);
    
    if (isCompleted) return 'completed';
    if (now > scheduledDateTime) return 'overdue';
    if (now.getTime() + 30 * 60 * 1000 > scheduledDateTime.getTime()) return 'upcoming';
    return 'scheduled';
  };

  const filteredTasks = tasks?.filter(task => {
    const memberMatch = selectedMember === "All" || task.assignedTo === selectedMember;
    const typeMatch = selectedTaskType === "All" || task.taskType === selectedTaskType;
    return memberMatch && typeMatch;
  }).sort((a, b) => a.scheduledTime.localeCompare(b.scheduledTime)) || [];

  const familyMembers = ["All", "Emma", "Alex", "Sarah", "Jake"];
  const taskTypes = ["All", "chore", "routine", "meal", "activity"];

  if (tasksLoading || statsLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Clock className="h-8 w-8 text-primary" />
              <div>
                <p className="text-2xl font-bold">{stats?.totalTasks || 0}</p>
                <p className="text-sm text-gray-600">Total Tasks Today</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-8 w-8 text-secondary" />
              <div>
                <p className="text-2xl font-bold">{stats?.completedToday || 0}</p>
                <p className="text-sm text-gray-600">Completed Today</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Potential Earnings Dashboard for Kids */}
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Apple className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-2xl font-bold text-purple-700">
                  ${(((filteredTasks?.filter(task => !task.isCompleted && task.value && task.value > 0)
                    .reduce((sum, task) => sum + (task.value || 0), 0)) || 0) / 100).toFixed(2)}
                </p>
                <p className="text-sm text-purple-600">Today's Potential</p>
                <p className="text-xs text-purple-500">
                  {filteredTasks?.filter(task => !task.isCompleted && task.value && task.value > 0).length || 0} tasks remaining
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Sparkles className="h-8 w-8 text-accent" />
              <div>
                <p className="text-2xl font-bold">${(stats?.weeklyEarnings || 0).toFixed(2)}</p>
                <p className="text-sm text-gray-600">Weekly Earnings</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter Controls */}
      <div className="space-y-4">
        {/* Role Toggle */}
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-700">View Mode:</h3>
          <div className="flex items-center space-x-2">
            <Button
              variant={userRole === "parent" ? "default" : "outline"}
              onClick={() => setUserRole("parent")}
              size="sm"
              className="flex items-center space-x-2"
            >
              <Users className="h-4 w-4" />
              <span>Parent</span>
            </Button>
            <Button
              variant={userRole === "child" ? "default" : "outline"}
              onClick={() => setUserRole("child")}
              size="sm"
              className="flex items-center space-x-2"
            >
              <User className="h-4 w-4" />
              <span>Kid</span>
            </Button>
          </div>
        </div>

        {/* Member Filter */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Filter by family member:</h3>
          <div className="flex space-x-2">
            {familyMembers.map((member) => (
              <Button
                key={member}
                variant={selectedMember === member ? "default" : "outline"}
                onClick={() => setSelectedMember(member)}
                className="px-4 py-2"
              >
                {member}
              </Button>
            ))}
          </div>
        </div>

        {/* Task Type Filter */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Filter by task type:</h3>
          <div className="flex space-x-2">
            {taskTypes.map((type) => (
              <Button
                key={type}
                variant={selectedTaskType === type ? "default" : "outline"}
                onClick={() => setSelectedTaskType(type)}
                size="sm"
                className="capitalize"
              >
                {type === "All" ? "All" : 
                 type === "chore" ? "🏠 Chores" :
                 type === "routine" ? "⏰ Routines" :
                 type === "meal" ? "🍽️ Meals" :
                 type === "activity" ? "📚 Activities" : type}
              </Button>
            ))}
          </div>
        </div>


      </div>

      {/* Daily Schedule */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5" />
              <span>Today's Schedule - {selectedMember}</span>
            </CardTitle>
            {isParent && (
              <Button 
                onClick={() => rotateChoresMutation.mutate()}
                disabled={rotateChoresMutation.isPending}
                size="sm"
                variant="outline"
              >
                🔄 {rotateChoresMutation.isPending ? 'Rotating...' : 'Rotate Chores'}
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredTasks.map((task) => {
              const IconComponent = iconMap[task.icon] || Clock;
              const timeStatus = getTimeStatus(task.scheduledTime, task.isCompleted);
              
              return (
                <div key={task.id} className={`p-4 border rounded-lg transition-all ${
                  task.isCompleted 
                    ? 'bg-green-50 border-green-200' 
                    : timeStatus === 'overdue' 
                    ? 'bg-red-50 border-red-200'
                    : timeStatus === 'upcoming'
                    ? 'bg-yellow-50 border-yellow-200'
                    : 'bg-white border-gray-200'
                }`}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className={`p-2 rounded-full ${
                        task.isCompleted ? 'bg-green-100' : 'bg-gray-100'
                      }`}>
                        <IconComponent className={`h-5 w-5 ${
                          task.isCompleted ? 'text-green-600' : 'text-gray-600'
                        }`} />
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className={`font-medium ${
                            task.isCompleted ? 'line-through text-gray-500' : 'text-gray-900'
                          }`}>
                            {task.title}
                          </h3>
                          {task.alarmEnabled && (
                            <Bell className="h-4 w-4 text-blue-500" />
                          )}
                          {task.recurring && (
                            <div className="flex items-center space-x-1">
                              <RotateCcw className="h-4 w-4 text-indigo-500" />
                              {task.streakCount > 0 && (
                                <div className="flex items-center space-x-1 bg-orange-100 text-orange-700 px-2 py-1 rounded-full text-xs">
                                  <Flame className="h-3 w-3" />
                                  <span>{task.streakCount} day{task.streakCount !== 1 ? 's' : ''}</span>
                                </div>
                              )}
                            </div>
                          )}
                          <Badge className={taskTypeColors[task.taskType as keyof typeof taskTypeColors]}>
                            {task.taskType}
                          </Badge>
                          {task.value > 0 && (
                            <Badge variant="outline" className="text-green-600">
                              ${(task.value / 100).toFixed(2)}
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-sm text-gray-600 mb-2">{task.description}</p>
                        
                        <div className="flex items-center space-x-4 text-sm">
                          <span className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>{formatTime(task.scheduledTime)}</span>
                          </span>
                          
                          <span className="font-medium text-primary">{task.assignedTo}</span>
                          
                          {task.recurring && (
                            <div className="flex items-center space-x-1 text-indigo-600">
                              <Calendar className="h-4 w-4" />
                              <span className="text-xs">
                                {getRecurringDaysText(task.recurringDays)}
                              </span>
                            </div>
                          )}
                          
                          {task.isCompleted && task.completedAt && (
                            <span className="text-green-600">
                              ✓ Completed {new Date(task.completedAt).toLocaleTimeString()}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Time Estimation Challenge Integration - Only show when task has gamification enabled */}
                    {task.gamificationEnabled && (
                      <div className="mt-4">
                        <TimeEstimationChallenge 
                          task={{
                            id: task.id,
                            title: task.title,
                            assignedTo: task.assignedTo,
                            estimatedMinutes: task.estimatedMinutes,
                            startedAt: task.startedAt,
                            actualMinutes: task.actualMinutes,
                            estimationPoints: task.estimationPoints,
                            isCompleted: task.isCompleted
                          }}
                          onChallengeComplete={() => {
                            queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
                            queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
                          }}
                        />
                      </div>
                    )}

                    <div className="flex items-center space-x-2">
                      {task.isCompleted && task.photoUrl && (
                        <img 
                          src={task.photoUrl} 
                          alt="Completion photo" 
                          className="w-12 h-12 object-cover rounded-lg"
                        />
                      )}
                      
                      {!task.isCompleted && (!task.gamificationEnabled || !task.startedAt) && (
                        <div className="flex space-x-2">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                handleFileSelect(task.id, file);
                              }
                            }}
                            className="hidden"
                            id={`photo-${task.id}`}
                          />
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="cursor-pointer"
                            disabled={photoUploadMutation.isPending}
                            onClick={() => document.getElementById(`photo-${task.id}`)?.click()}
                          >
                            <Camera className="h-4 w-4 mr-1" />
                            {photoUploadMutation.isPending ? 'Uploading...' : task.gamificationEnabled ? 'Complete (No Timer)' : 'Complete Task'}
                          </Button>
                          {isParent && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setEditingTask(task);
                                  setNewTime(task.scheduledTime);
                                }}
                              >
                                ⏰ Edit Time
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setEditingSchedule(task);
                                  const days = task.recurringDays ? task.recurringDays.split(',').map(d => parseInt(d)) : [1,2,3,4,5,6,7];
                                  setSelectedDays(days);
                                }}
                              >
                                📅 Edit Days
                              </Button>
                              
                              {/* Per-task Gamification Toggle */}
                              <div className="flex items-center space-x-2 px-2 py-1 bg-gray-50 rounded-lg">
                                <Gamepad2 className="h-4 w-4 text-purple-600" />
                                <span className="text-xs text-gray-700">Timer Challenge:</span>
                                <Switch
                                  checked={task.gamificationEnabled || false}
                                  onCheckedChange={async (checked) => {
                                    try {
                                      await apiRequest("PATCH", `/api/daily-tasks/${task.id}`, {
                                        gamificationEnabled: checked
                                      });
                                      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
                                    } catch (error) {
                                      console.error("Failed to update gamification setting:", error);
                                    }
                                  }}
                                  className="scale-75"
                                />
                                <span className="text-xs text-purple-600">
                                  {task.gamificationEnabled ? "On" : "Off"}
                                </span>
                              </div>
                            </>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}

            {filteredTasks.length === 0 && (
              <div className="text-center py-8">
                <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No tasks scheduled</h3>
                <p className="text-gray-500">No tasks found for the selected family member.</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Edit Time Dialog */}
      <Dialog open={!!editingTask} onOpenChange={() => setEditingTask(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Task Time</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Task: {editingTask?.title}</Label>
              <p className="text-sm text-gray-600">For: {editingTask?.assignedTo}</p>
            </div>
            <div>
              <Label htmlFor="newTime">New Time</Label>
              <Input
                id="newTime"
                type="time"
                value={newTime}
                onChange={(e) => setNewTime(e.target.value)}
                className="mt-1"
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setEditingTask(null)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (editingTask && newTime) {
                    // If task is recurring, show confirmation prompt
                    if (editingTask.recurring) {
                      setPendingTimeUpdate({ taskId: editingTask.id, newTime });
                      setShowRecurringPrompt(true);
                    } else {
                      editTimeMutation.mutate({ taskId: editingTask.id, newTime, updateType: 'today' });
                    }
                  }
                }}
                disabled={editTimeMutation.isPending}
              >
                {editTimeMutation.isPending ? 'Updating...' : 'Update Time'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Weekly Schedule Dialog */}
      <Dialog open={!!editingSchedule} onOpenChange={() => setEditingSchedule(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Weekly Schedule</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Task: {editingSchedule?.title}</Label>
              <p className="text-sm text-gray-600">For: {editingSchedule?.assignedTo}</p>
            </div>
            <div>
              <Label>Select Days</Label>
              <div className="grid grid-cols-4 gap-2 mt-2">
                {[
                  { day: 1, name: 'Mon' },
                  { day: 2, name: 'Tue' },
                  { day: 3, name: 'Wed' },
                  { day: 4, name: 'Thu' },
                  { day: 5, name: 'Fri' },
                  { day: 6, name: 'Sat' },
                  { day: 7, name: 'Sun' },
                ].map(({ day, name }) => (
                  <Button
                    key={day}
                    variant={selectedDays.includes(day) ? "default" : "outline"}
                    size="sm"
                    onClick={() => {
                      if (selectedDays.includes(day)) {
                        setSelectedDays(selectedDays.filter(d => d !== day));
                      } else {
                        setSelectedDays([...selectedDays, day]);
                      }
                    }}
                  >
                    {name}
                  </Button>
                ))}
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setEditingSchedule(null)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (editingSchedule && selectedDays.length > 0) {
                    editScheduleMutation.mutate({ taskId: editingSchedule.id, days: selectedDays });
                  }
                }}
                disabled={editScheduleMutation.isPending || selectedDays.length === 0}
              >
                {editScheduleMutation.isPending ? 'Updating...' : 'Update Schedule'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Recurring Task Change Confirmation Dialog */}
      <Dialog open={showRecurringPrompt} onOpenChange={setShowRecurringPrompt}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Recurring Task</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              This is a recurring task. How would you like to apply the time change?
            </p>
            <div className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => {
                  if (pendingTimeUpdate) {
                    editTimeMutation.mutate({ 
                      taskId: pendingTimeUpdate.taskId, 
                      newTime: pendingTimeUpdate.newTime, 
                      updateType: 'today' 
                    });
                  }
                }}
              >
                <span className="font-medium">Today Only</span>
                <span className="text-sm text-gray-500 ml-2">- Change just this occurrence</span>
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => {
                  if (pendingTimeUpdate) {
                    editTimeMutation.mutate({ 
                      taskId: pendingTimeUpdate.taskId, 
                      newTime: pendingTimeUpdate.newTime, 
                      updateType: 'future' 
                    });
                  }
                }}
              >
                <span className="font-medium">All Future Occurrences</span>
                <span className="text-sm text-gray-500 ml-2">- Change this and all future schedules</span>
              </Button>
            </div>
            <div className="flex justify-end">
              <Button variant="ghost" onClick={() => setShowRecurringPrompt(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Enhanced Add Task Modal */}
      <AddTaskModal 
        open={showAddTask} 
        onOpenChange={setShowAddTask} 
      />
    </div>
  );
}