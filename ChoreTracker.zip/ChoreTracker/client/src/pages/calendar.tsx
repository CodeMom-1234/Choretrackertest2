import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon,
  ArrowLeft,
  Clock,
  CheckCircle,
  Settings,
  DollarSign
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DailyTask {
  id: number;
  title: string;
  description: string;
  assignedTo: string;
  taskType: string;
  scheduledTime: string;
  value: number;
  isCompleted: boolean;
  completedAt: string | null;
  photoUrl: string | null;
  icon: string;
  alarmEnabled: boolean;
  recurring: boolean;
  lastCompletedDate: string | null;
  streakCount: number;
  recurringDays: string;
  isRotating: boolean;
  rotationGroup: string | null;
  rotationOrder: number;
}

const FAMILY_COLORS = {
  Emma: 'bg-pink-100 text-pink-800',
  Alex: 'bg-blue-100 text-blue-800',
  Sarah: 'bg-green-100 text-green-800',
  Jake: 'bg-yellow-100 text-yellow-800',
};

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedMember, setSelectedMember] = useState<string>("All");
  const [selectedTaskType, setSelectedTaskType] = useState<string>("All");
  const [showTaskAssignment, setShowTaskAssignment] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<number | null>(null);
  const [editTime, setEditTime] = useState<string>("");
  const [editValue, setEditValue] = useState<string>("");
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const { toast } = useToast();
  
  const { data: tasks } = useQuery<DailyTask[]>({
    queryKey: ['/api/daily-tasks'],
  });

  const familyMembers = ["All", "Emma", "Alex", "Sarah", "Jake"];
  const taskTypes = ["All", "chore", "routine", "meal", "activity"];

  // Update task mutation
  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, time, value, days }: { taskId: number; time: string; value: number; days: number[] }) => {
      const updateData: any = {
        scheduledTime: time,
        value: value,
        recurringDays: days.join(',')
      };
      
      return await apiRequest("PATCH", `/api/daily-tasks/${taskId}`, updateData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/daily-tasks'] });
      setSelectedTaskId(null);
      setEditTime("");
      setEditValue("");
      setSelectedDays([]);
      toast({
        title: "Success",
        description: "Task updated successfully!",
      });
    },
    onError: (error) => {
      console.error('Error updating task:', error);
      toast({
        title: "Error",
        description: "Failed to update task. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Filter tasks
  const getFilteredTasks = () => {
    if (!tasks) return [];
    
    return tasks.filter(task => 
      (selectedTaskType === "All" || task.taskType === selectedTaskType) &&
      (selectedMember === "All" || task.assignedTo === selectedMember)
    );
  };

  // Calendar navigation
  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (direction === 'prev') {
      newDate.setMonth(newDate.getMonth() - 1);
    } else {
      newDate.setMonth(newDate.getMonth() + 1);
    }
    setCurrentDate(newDate);
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  // Get tasks for a specific date
  const getTasksForDate = (date: Date) => {
    const dayOfWeek = date.getDay() === 0 ? 7 : date.getDay();
    return getFilteredTasks().filter(task => {
      if (!task.recurring || !task.recurringDays) return false;
      const taskDays = task.recurringDays.split(',').map(d => parseInt(d));
      return taskDays.includes(dayOfWeek);
    });
  };

  // Convert 24-hour to 12-hour format
  const formatTimeTo12Hour = (time24: string) => {
    if (!time24) return "";
    const [hours, minutes] = time24.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  // Convert 12-hour to 24-hour format
  const formatTimeTo24Hour = (time12: string) => {
    if (!time12) return "";
    const match = time12.match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (!match) return time12;
    
    let [, hours, minutes, ampm] = match;
    let hour = parseInt(hours);
    
    if (ampm.toUpperCase() === 'PM' && hour !== 12) {
      hour += 12;
    } else if (ampm.toUpperCase() === 'AM' && hour === 12) {
      hour = 0;
    }
    
    return `${hour.toString().padStart(2, '0')}:${minutes}`;
  };

  // Handle task selection for editing
  const selectTaskForEditing = (task: DailyTask) => {
    setSelectedTaskId(task.id);
    setEditTime(task.scheduledTime || "");
    setEditValue(task.value ? (task.value / 100).toFixed(2) : "0.00");
    const currentDays = task.recurringDays ? task.recurringDays.split(',').map(d => parseInt(d)) : [];
    setSelectedDays(currentDays);
  };

  // Toggle day selection
  const toggleDay = (dayNum: number) => {
    setSelectedDays(prev => 
      prev.includes(dayNum) 
        ? prev.filter(d => d !== dayNum)
        : [...prev, dayNum]
    );
  };

  // Apply changes
  const applyChanges = () => {
    if (selectedTaskId && selectedDays.length > 0) {
      const valueInCents = editValue ? Math.round(parseFloat(editValue) * 100) : 0;
      updateTaskMutation.mutate({
        taskId: selectedTaskId,
        time: editTime,
        value: valueInCents,
        days: selectedDays
      });
    }
  };

  // Calendar rendering
  const today = new Date();
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startDate = new Date(firstDay);
  startDate.setDate(startDate.getDate() - (firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1));

  const calendarDays = [];
  for (let i = 0; i < 42; i++) {
    const date = new Date(startDate);
    date.setDate(startDate.getDate() + i);
    calendarDays.push(date);
  }

  const selectedTask = tasks?.find(t => t.id === selectedTaskId);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto p-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                <CalendarIcon className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Calendar View</h1>
                <p className="text-sm text-gray-500">Monthly family schedule overview</p>
              </div>
              <Link href="/">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Daily Schedule
                </Button>
              </Link>
            </div>
            <div className="flex items-center space-x-2">
              <Button 
                onClick={() => setShowTaskAssignment(!showTaskAssignment)}
                className="flex items-center space-x-2"
                size="sm"
                variant={showTaskAssignment ? "default" : "outline"}
              >
                <Settings className="h-4 w-4" />
                <span>{showTaskAssignment ? "Hide Assignment" : "Assign Tasks"}</span>
              </Button>
              <Button variant="outline" size="sm" onClick={goToToday}>
                Today
              </Button>
              <Button variant="outline" size="sm" onClick={() => navigateMonth('prev')}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-lg font-semibold min-w-[150px] text-center">
                {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </span>
              <Button variant="outline" size="sm" onClick={() => navigateMonth('next')}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Filters */}
          <div className="flex items-center space-x-4 mb-6">
            <div className="flex items-center space-x-2">
              <Label>Member:</Label>
              <Select value={selectedMember} onValueChange={setSelectedMember}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {familyMembers.map(member => (
                    <SelectItem key={member} value={member}>{member}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Label>Type:</Label>
              <Select value={selectedTaskType} onValueChange={setSelectedTaskType}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {taskTypes.map(type => (
                    <SelectItem key={type} value={type}>
                      {type === "All" ? "All" : type.charAt(0).toUpperCase() + type.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Task Assignment Panel */}
          {showTaskAssignment && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="h-5 w-5" />
                  <span>Task Assignment</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Task Selection */}
                  <div className="space-y-4">
                    <h3 className="font-medium">Select Task to Edit</h3>
                    <div className="grid gap-2 max-h-64 overflow-y-auto">
                      {getFilteredTasks().map(task => (
                        <div
                          key={task.id}
                          onClick={() => selectTaskForEditing(task)}
                          className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                            selectedTaskId === task.id ? 'bg-blue-50 border-blue-300' : 'hover:bg-gray-50'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="font-medium">{task.title}</div>
                              <div className="text-sm text-gray-600">{task.description}</div>
                              <div className="flex items-center space-x-2 mt-1">
                                <Badge className={FAMILY_COLORS[task.assignedTo as keyof typeof FAMILY_COLORS] || 'bg-gray-100'}>
                                  {task.assignedTo}
                                </Badge>
                                {task.value > 0 && (
                                  <Badge variant="outline">
                                    ${(task.value / 100).toFixed(2)}
                                  </Badge>
                                )}
                              </div>
                            </div>
                            <div className="text-sm text-gray-500">
                              {formatTimeTo12Hour(task.scheduledTime)}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Task Editing */}
                  {selectedTask && (
                    <div className="space-y-4">
                      <h3 className="font-medium">Edit: {selectedTask.title}</h3>
                      
                      {/* Time Input */}
                      <div className="space-y-2">
                        <Label htmlFor="edit-time">Scheduled Time</Label>
                        <Input
                          id="edit-time"
                          type="time"
                          value={editTime}
                          onChange={(e) => setEditTime(e.target.value)}
                        />
                      </div>

                      {/* Value Input */}
                      <div className="space-y-2">
                        <Label htmlFor="edit-value">Task Value ($)</Label>
                        <Input
                          id="edit-value"
                          type="number"
                          step="0.01"
                          min="0"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          placeholder="0.00"
                        />
                      </div>

                      {/* Day Selection */}
                      <div className="space-y-2">
                        <Label>Select Days</Label>
                        <div className="grid grid-cols-7 gap-2">
                          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
                            const dayNum = index + 1;
                            const isSelected = selectedDays.includes(dayNum);
                            
                            return (
                              <Button
                                key={day}
                                variant={isSelected ? "default" : "outline"}
                                size="sm"
                                onClick={() => toggleDay(dayNum)}
                                className="text-xs"
                              >
                                {day}
                              </Button>
                            );
                          })}
                        </div>
                      </div>

                      <Button
                        onClick={applyChanges}
                        disabled={selectedDays.length === 0 || updateTaskMutation.isPending}
                        className="w-full"
                      >
                        {updateTaskMutation.isPending ? "Updating..." : "Apply Changes"}
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Calendar Grid */}
          <Card>
            <CardHeader>
              <CardTitle>Monthly Calendar</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2 mb-4">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                  <div key={day} className="text-center font-semibold text-sm text-gray-600 p-2">
                    {day}
                  </div>
                ))}
              </div>
              
              <div className="grid grid-cols-7 gap-2">
                {calendarDays.map((date, index) => {
                  const isCurrentMonth = date.getMonth() === month;
                  const isToday = date.toDateString() === today.toDateString();
                  const dayTasks = getTasksForDate(date);
                  
                  return (
                    <div
                      key={index}
                      className={`min-h-[100px] p-2 border rounded-lg ${
                        isCurrentMonth ? 'bg-white' : 'bg-gray-50'
                      } ${isToday ? 'ring-2 ring-blue-500' : ''}`}
                    >
                      <div className={`text-sm font-medium mb-2 ${
                        !isCurrentMonth ? 'text-gray-400' : isToday ? 'text-blue-600 font-bold' : ''
                      }`}>
                        {date.getDate()}
                      </div>
                      
                      <div className="space-y-1">
                        {dayTasks.slice(0, 3).map(task => (
                          <div
                            key={`${task.id}-${date.toDateString()}`}
                            className={`text-xs p-1 rounded border ${
                              FAMILY_COLORS[task.assignedTo as keyof typeof FAMILY_COLORS] || 'bg-gray-100'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="truncate font-medium">{task.title}</span>
                              <Clock className="h-3 w-3 ml-1 flex-shrink-0" />
                            </div>
                            <div className="text-xs opacity-75">
                              {formatTimeTo12Hour(task.scheduledTime)} • {task.assignedTo}
                            </div>
                          </div>
                        ))}
                        
                        {dayTasks.length > 3 && (
                          <div className="text-xs text-gray-500 text-center">
                            +{dayTasks.length - 3} more
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Today's Summary */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span>Today's Schedule</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {getTasksForDate(today).map(task => (
                  <div key={task.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Badge className={FAMILY_COLORS[task.assignedTo as keyof typeof FAMILY_COLORS] || 'bg-gray-100'}>
                        {task.assignedTo}
                      </Badge>
                      <div>
                        <div className="font-medium">{task.title}</div>
                        <div className="text-sm text-gray-600">{task.description}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="text-sm font-medium">{formatTimeTo12Hour(task.scheduledTime)}</div>
                      {task.value > 0 && (
                        <Badge variant="secondary">${(task.value / 100).toFixed(2)}</Badge>
                      )}
                      {task.isCompleted && (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}